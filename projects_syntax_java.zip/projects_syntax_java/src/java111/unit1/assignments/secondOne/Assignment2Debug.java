
// *@author    eknapp

public class Assignment2Debug {
    public static void main(String[] args){
        Person fred = new Person();
        fred.name = "Fred";
        fred.lastName = "Flinstone";
        fred.fullName();

    }

    public static class Person{
        String  name;    
        String  lastName; 

         public void fullName() {
            System.out.println("Here is the full name: " + name + " " + lastName);
         }
    }
}