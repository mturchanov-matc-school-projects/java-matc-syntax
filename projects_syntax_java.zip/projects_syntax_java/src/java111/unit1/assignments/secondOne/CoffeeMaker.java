public class CoffeeMaker{

    public void makeWeakCoffee(){
        System.out.println("The coffee machine has prepared a cup of weak coffee!");
    }
    public void makeStrongCoffee(){
         System.out.println("The coffee machine has prepared a cup of strong coffee!");

    }
}