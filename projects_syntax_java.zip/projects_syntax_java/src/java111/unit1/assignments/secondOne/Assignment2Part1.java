public class Assignment2Part1{
    public static void main(String[] args){

        CoffeeMaker coffeeMaker1 = new CoffeeMaker();

        coffeeMaker1.makeWeakCoffee();
        coffeeMaker1.makeStrongCoffee();
    
     
    }
    
}