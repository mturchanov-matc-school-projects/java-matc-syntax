public class Assignment1Part2{
    public static void main(String[] args){
        int counter = 0;
        while(counter < 10){
            if(counter == 0){
                System.out.println("First Time!");
            } else if(counter == 4) {
                System.out.println("Half-way there");
            } else if(counter == 9) {
                System.out.println("All done!");
            } else {
                System.out.println(counter);
            }
            
            counter++;
        }
    }
}