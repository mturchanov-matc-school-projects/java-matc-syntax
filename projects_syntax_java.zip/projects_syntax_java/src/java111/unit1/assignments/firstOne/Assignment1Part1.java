public class Assignment1Part1{
    public static void main(String[] args){
        int counter = 0;
        while(counter < 5){
            System.out.println(counter);
            counter++;
        }
    }
}