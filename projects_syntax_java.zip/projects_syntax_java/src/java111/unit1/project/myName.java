public class myName{
    public static void main(String[] args){
        
        System.out.println("Mykhailo Turchanov");
        System.out.println("mturchanov@madisoncollege.edu");
        

    }


}