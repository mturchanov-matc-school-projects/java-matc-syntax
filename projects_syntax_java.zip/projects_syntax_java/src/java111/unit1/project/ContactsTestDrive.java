public  class ContactsTestDrive{
    public static void main(String[] args){
        Contact person1 = new Contact();
        person1.firstName = "Dimitry";
        person1.lastName = "Smith";
        person1.address = "2191 Oak Street apt#222";
        person1.phone = "608-666-1233";
        person1.email = "contact@email.com";

        person1.display();

        Contact person2 = new Contact();
        person2.firstName = "John";
        person2.lastName = "Reeland";
        person2.address = "6666 Mineral Point apt#123";
        person2.phone = "608-123-8403";
        person2.email = "writeme@email.com";

        person2.display();
    }
}