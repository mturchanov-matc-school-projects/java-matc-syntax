public class MyNameLoopTestDrive{
    public static void main(String[] args){

        MyNameLoop person1 = new MyNameLoop();
        person1.fullName = "Mike Turchanov";
        person1.loopTheName();
    }
}