public class Contact{
    String firstName;
    String lastName;
    String address;
    String phone;
    String email;


    public void display(){
        System.out.println(firstName);
        System.out.println(lastName);
        System.out.println(address);
        System.out.println(phone);
        System.out.println(email + "\n");

    }
}