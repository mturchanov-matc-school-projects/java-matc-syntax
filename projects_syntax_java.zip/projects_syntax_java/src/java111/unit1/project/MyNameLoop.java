public class MyNameLoop{
    String fullName;
    int counter = 10;
    
    public void loopTheName(){
        while(counter > 0) {
            System.out.println(fullName);
            counter--;
        }
    }
}