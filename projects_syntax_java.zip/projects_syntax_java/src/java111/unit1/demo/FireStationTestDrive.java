public class FireStationTestDrive {
    public static void main(String[] args) {
        int age = 25;
        FireTruck fireTruck;
        fireTruck = new FireTruck();
        fireTruck.identify();
    }
}
