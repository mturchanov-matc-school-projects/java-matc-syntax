public class TheUpsideDown {
    public String monster;
    public int hitPoints;

    public void showHitPoints() {
        System.out.println("Hit points: " + hitPoints);
    }
}
