public class Cat{
    void meow(){
        System.out.println("Meow meow! I am a cat.");
    }
}