public class FireTruck {
    public void identify() {
        System.out.println("I'm fire truck number 7.");
    }
}
