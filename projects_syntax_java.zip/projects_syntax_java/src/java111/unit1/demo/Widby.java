public class Widby {
    public void method1() {
        System.out.println("I'm in method1.");
    }

    public void add(int num1, int num2) {
        int num3;
        num3 = num1 + num2;
        System.out.println(num1 + " plus " + num2 + " equals " + num3);
    }

    public void displayNames(String name, int count) {
        for (int innerCounter = 0; innerCounter < count; ++innerCounter) {
            System.out.println(name);
        }
    }

    public double subtract(double firstNum, double secondNum) {
        double result = firstNum - secondNum;
        return result;
    }

    public String concatenateStrings(String firstName, String lastName) {
        return (firstName + " " + lastName);
    }
}
