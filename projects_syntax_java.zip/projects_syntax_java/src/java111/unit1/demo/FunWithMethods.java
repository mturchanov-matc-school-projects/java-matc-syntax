public class FunWithMethods {
    public static void main(String[] args) {
        Widby widby = new Widby();
        widby.method1();
        int firstNum = 3;
        int secondNum = 5;
        widby.add(firstNum, secondNum);
        String name = "Justin Bieber";
        widby.displayNames(name, 4);

        double subtractionResult;
        subtractionResult = widby.subtract(123.45, 23.45);

        String concatenatedName;
        concatenatedName = widby.concatenateStrings("Mickey", "Mouse");
        System.out.println(concatenatedName);
    }
}
