public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!!!");

        int age;
        age = 25;
        //age = "ten";
        System.out.println("My age is " + age);

        double adultAdmission;
        adultAdmission = 14.99;

        double youthAdmission;
        youthAdmission = 8.99;

        String name;
        name = "Cary";

        if (age > 16) {
            System.out.println(name + ", since you're over 16, the admission is " + adultAdmission);
        }
        else {
            System.out.println(name + ", since you're 16 or younger, the admission is " + youthAdmission);
        }

        boolean carOwner = true;
        if (carOwner == true) {
            System.out.println("You can drive yourself to the movies.");
        }
        else {
            System.out.println("Call Uber.");
        }
    }
}
