public class LoopingApp {
    public static void main(String[] args) {
        int max;
        max = 10;
        int counter = 0;
        while (counter < max) {
            System.out.println("Counter is " + counter + ".");
            counter++;
        }

        // Following redeclares counter. This is not what we want, nor allowed.
        /*for (int counter = 0; counter < max; ++counter) {
        }

        String counter = "George";*/

        // Very rarely do you see a for loop with the counter declared like this.
        for (int counter2 = 0; counter2 < max; counter2++) {
            System.out.println("Counter2 is " + counter2 + ".");
        }
    }
}
