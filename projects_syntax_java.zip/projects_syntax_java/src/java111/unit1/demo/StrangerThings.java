public class StrangerThings {
    public static void main(String[] args) {
        TheUpsideDown upsideDown = new TheUpsideDown();
        upsideDown.monster = "Demogorgon";
        upsideDown.hitPoints = 312;
        upsideDown.showHitPoints();
    }
}
