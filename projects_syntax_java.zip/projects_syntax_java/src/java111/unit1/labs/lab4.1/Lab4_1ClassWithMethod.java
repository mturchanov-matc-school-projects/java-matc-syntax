public class Lab4_1ClassWithMethod{
    public boolean greaterThanMillion(int num1,int num2){
        //return num1 * num2 > 1000000 ? true : false;
        int product = num1 * num2;
        int boundary = 1000000;

        if(product > boundary){
            return true;
        }
        return false;
    }


public void responseToComp(boolean response){
    if(response == false){
        System.out.println("The values are small.");
    } else {
    System.out.println("At least one of the values is big.");
    }

}

}