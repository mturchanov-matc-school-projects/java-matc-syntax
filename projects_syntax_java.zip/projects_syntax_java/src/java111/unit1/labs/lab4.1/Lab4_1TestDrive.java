public class Lab4_1TestDrive{
    public static void main(String[] args){

        Lab4_1ClassWithMethod meth = new Lab4_1ClassWithMethod();
        boolean comparison1 = meth.greaterThanMillion(5,8);
        meth.responseToComp(comparison1);

        boolean comparison2 = meth.greaterThanMillion(142142,124124);
        meth.responseToComp(comparison2);
    }
}