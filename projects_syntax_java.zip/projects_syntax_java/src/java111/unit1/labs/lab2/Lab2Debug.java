
/**
 *  Lab 2 Debugging exercise
 *
 *@author    eknapp
 */
public class Lab2Debug {

    /**
     *  The main program for the Lab2Debug class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {

        int x = 5;
        
        while (x > 0) {
            System.out.println("in the loop: " + x);
            //what goes after this line to stop the loop?
            x--;
        }
    }

}

