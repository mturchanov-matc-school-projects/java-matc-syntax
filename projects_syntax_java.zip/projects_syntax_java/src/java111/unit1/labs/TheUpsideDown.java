public class TheUpsideDown{
    public String;
    public int hitPoints;

    public void showHitPoints(){
        System.out.println("Hit points: " + hitPoints);
    }
}