public class StrangerThings{
     public static void main(String[] args){

         TheUpsideDown upsideDown = new UpsideDown();
         upsideDown.monster = "Demogorgon";
         upsideDown.hitPoints = 312;
         upsideDown.showHitPoints();
    }
}