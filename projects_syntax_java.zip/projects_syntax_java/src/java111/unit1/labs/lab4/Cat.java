public class Cat{
     static int count = 0;
    public void meow(){
        count++;
        System.out.println("Meow meow! I am a cat  number " + count );
        
    }
}