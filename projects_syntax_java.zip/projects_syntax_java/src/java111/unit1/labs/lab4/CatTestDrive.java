public class CatTestDrive{
    public static void main(String[] args){
       Cat kitty = new Cat();
       kitty.meow();
       Cat secondKitty = new Cat();
       secondKitty.meow();
    }
}