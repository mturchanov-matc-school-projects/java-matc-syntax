/** 
*
* The entry point of the application.
*
@author mturchanov
*/
public class CinemaTestDrive {
    public static void main(String[] args){
        ProcessDailySales test = new ProcessDailySales();
        test.tallyDay();
    }
}