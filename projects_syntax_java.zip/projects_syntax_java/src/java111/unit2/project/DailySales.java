/** 
*
* This class process daily sales of the theater.
*
*@author mturchanov
*/
public class DailySales {
    private MovieShowing[] movies;
    static public double dailySales;

    /** 
    *
    * This method retrieves the daily sales of the theater.
    *
    * @return The daily sales of the theater.
    *
    */
    public double getDailySales(){
        return dailySales;
    }

    /** 
    *
    * This method sets movies that are showed on the day.
    *
    * @param The movie names.
    *
    */
    public void setMovies(MovieShowing[] movies){
        this.movies = movies;
    }

    /** 
    *
    * This method calculates today's revenue.
    *
    */
    public void calculateTodaysRevenue(){
        double dailySales = 0.0;
        for(int i = 0; i < movies.length; i++){
            dailySales += movies[i].calculateRevenue();
        }
        this.dailySales = dailySales;

        System.out.println("\nDaily Total: " + dailySales
                 + "\n------------------------------");
    }
    /** 
    *
    * This method display information on each movie
    * that was showed today
    *
    * @return The movie name.
    *
    */
    public void displayDailySales(){
        double dailyRevenue = 0;
        for(int i = 0; i < movies.length; i++){
           System.out.println(movies[i].dispayShowingInfo());
        }
    }
}