/** 
*
* This class represents Movie Showing
*
* @author mturchanov
*
*/
public class MovieShowing{
    private int theaterNumber;
    private String movieName;
    private int numOfOccupiedSeats;
    private double ticketPrice;

    /** 
    *
    * This method sets the theater number.
    *
    *@param The theater number.
    *
    */
    public void setTheaterNumber(int theaterNumber){
        this.theaterNumber = theaterNumber;
    }

    /** 
    *
    * This method retrieves the theater number.
    *
    * @return The theater number.
    *
    */
    public int getTheaterNumber(){
        return theaterNumber;
    }

    /** 
    *
    * This method sets the movie name.
    *
    * @param The movie name.
    *
    */
    public void setMovieName(String movieName){
        this.movieName = movieName;
    }

    /** 
    *
    * This method retrieves the movie name.
    *
    * @return The movie name.
    *
    */
    public String getMovieName(){
        return movieName;
    }

    /** 
    *
    * This method sets the number of occupied seats in the theater.
    *
    * @param The number of occupied seats.
    *
    */
    public void setNumOfOccupiedSeats(int numOfOccupiedSeats){
        this.numOfOccupiedSeats = numOfOccupiedSeats;
    }

    /** 
    *
    * This method retrieves the number of occupied seats.
    *
    * @return The number of occupied seats.
    *
    */
    public int getNumOfOccupiedSeats(){
        return numOfOccupiedSeats;
    }

    /** 
    *
    * This method sets the ticket price.
    *
    * @param The ticket price.
    *
    */
    public void setTicketPrice(double ticketPrice){
        this.ticketPrice = ticketPrice;
    }

    /** 
    *
    * This method retrieves the ticket price.
    *
    * @return The ticket price.
    *
    */
    public double getTicketPrice(){
        return ticketPrice;
    }

    /** 
    *
    * This method calculate a revenue.
    *
    * @return The revenue that is calculated with: 
    * number of occupied seats devided by ticket price.
    *
    */
    public double calculateRevenue(){
        return numOfOccupiedSeats * ticketPrice;
    }

    /** 
    *
    * This method returns the full information 
    * regarding a movie and a theater
    *
    * @return The full movie information.
    *
    */
    public String dispayShowingInfo(){
        String movieFullInfo = "\nTheater Number: " + theaterNumber + "\nMovie Name: " + movieName
                + "\nNumber of occupied Seats: " + numOfOccupiedSeats
                + "\nTicket Price: " + ticketPrice + "\nTotal Revenue: " + calculateRevenue();
        return movieFullInfo;
    }
}