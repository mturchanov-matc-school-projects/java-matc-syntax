/** 
*
* The entry point of the application/output.
*
* @author mturchanov
*
*/
public class StudentTestDrive{
    public static void main(String[] args){
        ProcessStudents newStudents = new ProcessStudents();

        newStudents.runStudentProcessing();
    }
}