/** 
*
* This class process information 
regarding theaters and movies.
*
* @author mturchanov
*
*/
public class ProcessDailySales {
    public DailySales dayX;
    /** 
    *
    * This method sets/add movies and theaters information.
    *
    */
    private void createMovieShowings(){
        MovieShowing movies[] = new MovieShowing[3];
        movies[0] = new MovieShowing();
        movies[1] = new MovieShowing();
        movies[2] = new MovieShowing();
        
        movies[0].setTheaterNumber(13);
        movies[0].setMovieName("Jango");
        movies[0].setNumOfOccupiedSeats(40);
        movies[0].setTicketPrice(15.5);

        movies[1].setTheaterNumber(8);
        movies[1].setMovieName("Snatch");
        movies[1].setNumOfOccupiedSeats(5);
        movies[1].setTicketPrice(74.2);

        movies[2].setTheaterNumber(13);
        movies[2].setMovieName("Revengers");
        movies[2].setNumOfOccupiedSeats(33);
        movies[2].setTicketPrice(14);

        dayX.setMovies(movies);
    }
    
    /** 
    *
    * This method create,sets and display movies/theater information.
    *
    */
    public void tallyDay(){
        dayX = new DailySales();
        createMovieShowings();
        dayX.displayDailySales();
        dayX.getDailySales();
        dayX.calculateTodaysRevenue();
    }
}