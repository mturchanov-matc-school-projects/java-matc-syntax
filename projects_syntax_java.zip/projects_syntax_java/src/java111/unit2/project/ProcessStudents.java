package studentApplication;

/**
 *
 * This class process, groups and creates students' entries
 * 
 * @author mturchanov
 */
public class ProcessStudents{
    private Student[] students;

    /** 
    *
    * This method fills out/process students and their
    *  information.
    *
    */
    public void createStudents(){
        students = new Student[3];
        students[0] = new Student();
        students[1] = new Student();
        students[2] = new Student();

        students[0].setStudentName("Freddy");

        students[1].setStudentName("Mike");
        students[1].setStudentID(53513);
        students[1].setTotalCredits(34);
        students[1].setGradePoints(93);

        students[2].setStudentName("Tom");
        students[2].setStudentID(57612);
        students[2].setTotalCredits(87);
        students[2].setGradePoints(79);
    }

    /** 
    *
    * This method prints all students' information that was filled out.
    *
    */
    public void displayStudents(){
        for(int i = 0; i < students.length; i++){
            students[i].getStudentProfile();
        }
    }

    /** 
    *
    * This method creates/process students' and their information
    * and display them (on screen)
    *
    */
    public void runStudentProcessing(){
        createStudents();
        displayStudents();
    }
}