package studentApplication;

/**
*This class represents a Student
*
@author mturchanov
*
*/
public class Student{
    private String name;
    private int studentID = 99999; 
    private int totalCredits = 45;
    private int gradePoints = 100;

    /**
    This method sets the student's name.
    *
    @param name The name of the student
    *
    */
    public void setStudentName(String name){
        this.name = name;
    }

    /**
    * Retrieves the student's name
    *
    * @return the name of the student
    *
    */
    public String getStudentName(){
        return name;
    }

    /**
    *
    * This method sets the student's ID 
    *
    * @param studentID The studentID
    *
    */
    public void setStudentID(int studentID){
        this.studentID = studentID;  
    }

    /** 
    *
    * This method retrieves the student ID
    *
    * @return The student ID.
    *
    */
    public int getStudentID(){
        return studentID;
    }

    /** 
    *
    * This method sets the student's total credits.
    *
    * @param The student's total credits.
    *
    */
    public void setTotalCredits(int totalCredits){
        this.totalCredits = totalCredits;
    }

    /** 
    *
    * This method retrieves the student's totals credits
    *
    * @return The student's total credits.
    *
    */
    public int getTotalCredits(){
        return totalCredits;
    }

    /** 
    *
    * This method sets the grade points of the student.
    *
    * @param The student's grade points.
    *
    */    
    public void setGradePoints(int gradePoints){
        this.gradePoints = gradePoints;
    }

    /** 
    *
    * This method retrieves the student's grade points.
    *
    * @return The student's grade points.
    *
    */
    public int getGradePoints(){
        return gradePoints;
    }

    /** 
    *
    * This method calculates the student's GPA (Grade Point Average).
    *
    * @return GPA that is calculated via Grade Points devided by total credits.
    *
    */
    public double calculateGPA(){
        double gpa = (double)(gradePoints) / totalCredits;
        double scale = Math.pow(10, 2);
        return Math.round(gpa * scale) / scale;
    }


    /** 
    *
    * This method displays all student's information including his GPA
    *
    */
    public void getStudentProfile(){
        String studentProfile = "Student's Name: " + name + "\nStudent's ID: " + studentID
                + "\nTotal Credits: " + totalCredits + "\nGrade Points: " + gradePoints
                + "\nStudent's GPA: " + calculateGPA() + "\n---------------------------";

        System.out.println(studentProfile);
    }
}