public class LabSixTestDrive {
    public static void main(String[] args){
        
        LabSix test = new LabSix();
        test.run();
    }
}