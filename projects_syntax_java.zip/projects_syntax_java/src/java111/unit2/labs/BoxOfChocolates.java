public class BoxOfChocolates{
    Chocolate[] box = new Chocolate[3];


    public void setup(){
        Chocolate box0 = new Chocolate();
        box[0] = box0;
        Chocolate box1 = new Chocolate();
        box[1] = box1;
        Chocolate box2 = new Chocolate();
        box[2] = box2;
        box[0].setFilling("ipsumus");
        box[1].setFilling("corenus");
        box[2].setFilling("herecus");
        box[0].setCoating("jordinus");
        box[1].setCoating("lirius");
        box[2].setCoating("znacus");
        box[0].setRating(2);
        box[1].setRating(9999);
        box[2].setRating(5);
       
        
    }

    public void runWhile(){
        int i = 0;
        while(i < box.length){
            System.out.println(box[i].display());
            i++;
        }
        System.out.println(box.length); //Output the value of the loop counter.
    }

    public void runFor(){
        for(int i = 0; i < box.length;i++){
            System.out.println(box[i].display());
        }
        //System.out.println(i);
    }


}