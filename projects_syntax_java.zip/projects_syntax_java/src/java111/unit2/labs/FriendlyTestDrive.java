public class FriendlyTestDrive {
    public static void main(String[] args){
        Friendly obj1 = new Friendly();
        obj1.sayHello("Mike");
        obj1.sayHello("John");
        obj1.sayHello("Fred");
        obj1.sayHelloAgain("Fred",5);

    }
}