public class SingleChocolateTestDrive {
    public static void main(String[] args){
        Chocolate ch1 = new Chocolate();
        Chocolate ch2 = new Chocolate();
        Chocolate ch3 = new Chocolate();

        ch1.setFilling("ipsumus");
        ch2.setFilling("corenus");
        ch3.setFilling("herecus");

        ch1.setCoating("jordinus");
        ch2.setCoating("lirius");
        ch3.setCoating("znacus");

        ch1.setRating(2);
        ch2.setRating(9999);
        ch3.setRating(5);

        System.out.println(ch1.display());
        System.out.println(ch2.display());
        System.out.println(ch3.display());

        
    }
}