public class Chocolate{
    private String coating;
    private String filling;
    private int rating;

    public void setCoating(String coating){
        this.coating = coating;
    }

    public void setFilling(String filling){
        this.filling = filling;
    }

    public void setRating(int rating){
        this.rating = rating > 5 || rating < 0 ? 0 : rating;
    }

    public String getCoating(){
        return coating;
    }

    public String getFilling(){
        return filling;
    }
    public int getRating(){
         return rating;
    }

    public String display(){
        String str = "Coating: " + coating + "\nFilling: " + filling 
                + "\nRating: " + Integer.toString(rating) + "\n-----------------------";
        return str;
    }
}