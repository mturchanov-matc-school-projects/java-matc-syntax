public class LabTwoOneA{
    int testInt  = 5;
    long testLong = 78;
    double testDouble = 2.7;

    public double calculateAllTests(){
        return testInt*testDouble*testLong;
    }

    public double quotientOfNums(){
        return testLong / testInt;
    }

}