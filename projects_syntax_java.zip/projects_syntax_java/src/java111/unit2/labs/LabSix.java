public class LabSix {

    public void run(){
        int num1 = 5;
        int num2 = 10;
        int num3 = 3;
        int num4 = 25;

        int result = 0;
        double result2 = 0.0;
        result = num1 + num2 + num3 + num4;
        System.out.println(result);
        result2 = (num1 * num2 * num4) / 3.0;
        System.out.println(result2);
        }
}