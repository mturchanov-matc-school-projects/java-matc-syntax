public class BoxOfChocolatesTestDrive {
    public static void main(String[] args){
        BoxOfChocolates box1 = new BoxOfChocolates();
        box1.setup();
      
         box1.runWhile();
         box1.runWhile();
    }
}