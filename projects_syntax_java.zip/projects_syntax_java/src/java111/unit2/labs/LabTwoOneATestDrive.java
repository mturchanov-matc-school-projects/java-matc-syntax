public class LabTwoOneATestDrive{
    public static void main(String[] args){
        LabTwoOneA obj1 = new LabTwoOneA();
        double product = obj1.calculateAllTests();
        double quatient = obj1.quotientOfNums();
        System.out.println(product);
        System.out.println(quatient);

    }
}