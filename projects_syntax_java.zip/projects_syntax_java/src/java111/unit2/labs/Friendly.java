public class Friendly{

    public void sayHello(String name){
        System.out.println("Hello there, " + name);
    }
    public void sayHelloAgain(String name, int counter){
        for(int i = 0; i < counter;i++){
            System.out.println("Hi " + name);
        }
    }
}