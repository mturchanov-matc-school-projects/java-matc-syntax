public class AssignmentTwo{
    private Fruit fruits[];
    private int totalFruitCount = 0;

    public void run(){
        fruits = new Fruit[5];
        Fruit apple = new Fruit();
        fruits[0] = apple;
        fruits[0].setName("Apple");
        fruits[0].setNumber(10);

        Fruit peach = new Fruit();
        fruits[1] = peach;
        fruits[1].setName("Peach");
        fruits[1].setNumber(4);

        Fruit pineapple = new Fruit();
        fruits[2] = pineapple;
        fruits[2].setName("Pineapple");
        fruits[2].setNumber(100);

        Fruit strawberry = new Fruit();
        fruits[3] = strawberry;
        fruits[3].setName("Strawberry");
        fruits[3].setNumber(45);

        Fruit banana = new Fruit();
        fruits[4] = banana;
        fruits[4].setName("Banana");
        fruits[4].setNumber(4);

        for(Fruit fruit: fruits){
            totalFruitCount += fruit.getNumber();
        }
        System.out.print(totalFruitCount);

    }
}