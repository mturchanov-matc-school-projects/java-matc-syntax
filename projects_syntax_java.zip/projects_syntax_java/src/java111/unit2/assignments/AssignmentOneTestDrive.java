public class AssignmentOneTestDrive{
        public static void main(String[] args){

            AssignmentOne test = new AssignmentOne();
            test.runLoop();
        }

}