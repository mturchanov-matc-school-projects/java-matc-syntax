public class AssignmentOne{
    private int counter = 10;
    private double additionValue = 12.76;
    private double calculatedAmount;

    public void runLoop(){
        calculatedAmount = 0;

        while(0 < counter){
            calculatedAmount += additionValue;
            counter--;
        }
        System.out.println(calculatedAmount);
    }
}