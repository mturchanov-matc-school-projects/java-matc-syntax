public class BattleShip {
    public int length;

    public void setLength(int length) {
        if ((length < 350) || (length > 750)) {
            System.out.println("Error! Bad value for length!");
            return;
        }
        this.length = length;
    }

    public int getLength() {
        return length;
    }
}
