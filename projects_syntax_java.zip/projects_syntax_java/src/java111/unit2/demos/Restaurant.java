public class Restaurant {
    public static void main(String[] args) {
        WaitPerson steve = new WaitPerson();
        WaitPerson alice = new WaitPerson();

        // steve.pay = 2.50;
        // alice.pay = 3.50;

        steve.setPay(2.50);
        alice.setPay(3.50);
    }
}
