/** This class is the test drive
 *  for the Vehicle Fleet demo
 *
 *  @author <your name here>
 */

public class VehicleFleetTestDrive {

    /** The main method creates a BuildVehicleFleet object
     *  and calls the run() method.
     *
     *  @param args command line arguments
     */

     public static void main(String[] args) {
        /*Vehicle vehicle = new Vehicle();
        vehicle.setMake("Tesla");
        vehicle.setYear(2018);
        vehicle.setMileage(10000);
        String description = vehicle.getDescription();
        System.out.println(description);
        double mileage = vehicle.calculateMileage();
        System.out.println(mileage);*/

        Vehicle[] vehicles = new Vehicle[3];
        VehicleFleet fleet = new VehicleFleet();
      //   vehicles[0] = new Vehicle();
      //   vehicles[1]=new Vehicle();
      //     vehicles[2]=new Vehicle();
      //     for(int i = 0; i < vehicles.length;i++){
      //        String make = "S" + 
      //     }
      //   fleet.setVehicles(vehicles);
      System.out.println(fleet.calculateAnnualAverageMileage());
        

        BuildVehicleFleet builder = new BuildVehicleFleet();
        // builder.run();
        if(fleet == null || fleet.isEmpty()){
        fleet.displayVehicleInfo();
        }
        
     }
}
