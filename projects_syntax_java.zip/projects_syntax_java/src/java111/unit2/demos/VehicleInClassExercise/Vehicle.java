/** This class represents a vehicle
 *  which will be used to emphasize
 *  Unit 2 concepts and help you prepare
 *  for Project 2.
 *  @author <your name here>
 */

public class Vehicle {

    // Create private instance variables for make, year, and mileage.
    private String make;
    private int year;
    private double mileage;


    // Create public getters and setters for each instance variable
    public void setMake(String vehicleMake) {
        this.make = vehicleMake;
    }

    public String getMake() {
        return make;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getYear() {
        return year;
    }

    public void setMileage(double mileage) {
        this.mileage = mileage;
    }

    public double getMileage() {
        return mileage;
    }

    /** Create a method to calculate
     *  the average number of miles the vehicle
     *  was driven per year.  This value will be a double
     *
     *  @return average mileage per year
     */
    public double calculateMileage() {
        double averageMileage = mileage / (2020 - year);
        return averageMileage;
    }


     /** Create a method, display(), that returns a String containing the
      *  vehicle information. It should include all instance variables and
      *  average mileage per year.
      *
      *  @return vehicle details
      */
    public String getDescription() {
        String displayString;
        displayString = "Make: " + make + ", year: " + year + ", mileage: " + mileage;
        return displayString;
    }
}
