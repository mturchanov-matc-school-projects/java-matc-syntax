public class WaitPerson {
    private double pay;

    public void setPay(double thePay) {
        pay = thePay;
    }
}
