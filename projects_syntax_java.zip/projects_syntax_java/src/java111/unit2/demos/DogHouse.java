public class DogHouse{
    public static void main(String[] args){
        
        int[] snorks = new int[10];

        Dog[] dogs = new Dog[10];

        dogs = new Dog[10];

        dogs[3].setWetNose(true);

        for(int i = 0; i < dogs.length;i++){
            dogs[i] = new Dog();
            System.out.println("Hey");
        }




    }
}

