public class Dog {
    private boolean wetNose = false;
    private String name;

    public void setWetNose(boolean wetNose) {
        this.wetNose = wetNose;
    }

    public boolean getWetNose() {
        return wetNose;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void display() {
        if (wetNose) {
            System.out.println(name + " has a wet nose.");
        }
        else {
            System.out.println(name + " has a dry nose");
        }
    }
}
