public class NavalBaseTestDrive {
    public static void main(String[] args) {
        BattleShip ship1 = new BattleShip();
        ship1.setLength(580);

        BattleShip ship2 = new BattleShip();
        ship2.setLength(6000);
        // ship2.length = 6000;

        int len2 = ship2.getLength();
        System.out.println("The length of the second battleship is " + len2 + ".");
    }
}
