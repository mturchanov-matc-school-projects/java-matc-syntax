public class FunWithArrays {
    public static void main(String[] args) {
        // Oh! So hard to keep track of.
        /*int card1 = 1;
        int card2 = 2;
        int card3 = 3;

        int handCard1 = card3;
        int handCard2 = card7;*/

        int[] cards;
        cards = new int[13];
        //cards[0] = 1;
        cards[1] = 2;
        // cards[13] = 8;
        for (int counter = 0; counter < cards.length; ++counter) {
            cards[counter] = counter+1;
        }
        int myValue = cards[3];
        System.out.println("The 4th card is " + myValue + ".");
        for (int counter = 0; counter < cards.length; ++counter) {
            System.out.println("Card " + counter + " is " + cards[counter] + ".");
        }
        System.out.println(cards);
    }
}
