public class DogHouseTestDrive {
    public static void main(String[] args) {
        int[] snorks = new int[10];

        Dog[] dogs;
        // System.out.println("dogs 1: " + dogs);
        dogs = new Dog[10];
        System.out.println("dogs: " + dogs);

        System.out.println("dog at elem 4, 1: " + dogs[3]);

        // Run-time error! The dog was not allocated.
        //dogs[3].setWetNose(true);

        for (int dogCounter = 0; dogCounter < dogs.length; ++dogCounter) {
            dogs[dogCounter] = new Dog();
        }

        System.out.println("dog at elem 4, 2: " + dogs[3]);
        dogs[3].setWetNose(true);
        dogs[3].setName("Rex");
        dogs[3].display();

        dogs[4].setWetNose(false);
        dogs[4].setName("Fido");
        dogs[4].display();

        System.out.println("Dog at [3]:");
        dogs[3].display();
        System.out.println("Dog at [4]:");
        dogs[4].display();

        Dog currentDog = dogs[3];
        System.out.println("The current dog is at " + currentDog);

        // From this point forward, this is just demo'ing how confusing
        // memory, arrays and elements can get. Don't use this as an
        // example for what you should do!
        currentDog.setName("Baxter");
        System.out.println("Dog at [3]:");
        dogs[3].display();
        System.out.println("Dog at [4]:");
        dogs[4].display();

        dogs[4] = dogs[3];
        System.out.println("Dog at [3]:");
        dogs[3].display();
        System.out.println("Dog at [4]:");
        dogs[4].display();
    }
}
