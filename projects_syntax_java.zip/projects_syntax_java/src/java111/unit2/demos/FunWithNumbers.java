public class FunWithNumbers {
    public static void main(String[] args) {
        int intRes;
        int a = 7;
        int b = 3;
        intRes = a / b;
        System.out.println("intRes 1 = " + intRes);

        double realRes;
        double x = 7;
        double y = 3;
        realRes = x / y;
        System.out.println("realRes 1 = " + realRes);

        realRes = a / b;
        System.out.println("realRes 2 = " + realRes);

        realRes = a / (double)b;
        System.out.println("realRes 2 = " + realRes);

        // Can't! Compiler complains it won't fit.
        // intRes = x / y;
        intRes = (int)(x / y);
        System.out.println("intRes 2 = " + intRes);
    }
}
