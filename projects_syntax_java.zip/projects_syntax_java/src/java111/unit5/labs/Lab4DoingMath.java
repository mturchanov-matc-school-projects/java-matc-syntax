package java111.unit5.labs;
import java.math.BigDecimal;

public class Lab4DoingMath {

    private static int getRandom(int maxRange){
        return (int)(Math.random() * 1000);
    }

    private static double getSqrt(int ...nums){
        int sum = 0;
        for(int num : nums){
            sum += num;
        }
        return Math.sqrt(sum);
    }

    private static double roundNum(double num){
        return Math.round(num * 100) / 100.0;
    }

    private static BigDecimal multiplyPi(int multiplier){
        return new BigDecimal(Math.PI * multiplier);
    }

    public static void main(String[] args){
        System.out.printf("Random number between 1 and %d - %d%n%n",1000, getRandom(1000));

        System.out.printf("Square root of numbers - %.2f%n%n", getSqrt(123,123,21,3,54,35,3,6,4564,456,232));

        System.out.printf("Round a number to tenth - %.2f%n", roundNum(Math.PI));
        System.out.printf("Round a number to tenth - %.2f%n%n", roundNum(5.555));

        System.out.printf("Multiplication with PI - %s%n", multiplyPi(21));
    }
}