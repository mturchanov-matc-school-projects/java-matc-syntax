package java111.unit5.labs;

public class Lab3Override {
    String name = "unknown name";
    int size;

    public Lab3Override(){
        this.name = "unknown item";
        this.size = 0;
    }

    public Lab3Override(String name) {
        this.name = name;
    }

    public Lab3Override(int size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return String.format("Name: %s, size: %s", this.name, size == 0 ? "unknown size" : this.size);
    }
}