package java111.unit5.labs;

public class SubClassConstructorLab extends ConstructorLab {
    public SubClassConstructorLab() {
        System.out.println(this.getClass().getSimpleName());
    }
}