package java111.unit5.labs;

public class ConstructorLab {
    public ConstructorLab() {
        System.out.println(this.getClass().getSimpleName());
    }
}