package java111.unit5.labs;

public class Lab3OverrideTestDrive {
    public static void main(String[] args){
        System.out.println(new Lab3Override());
        System.out.println(new Lab3Override(10));
        System.out.println(new Lab3Override("coat"));
    }
}