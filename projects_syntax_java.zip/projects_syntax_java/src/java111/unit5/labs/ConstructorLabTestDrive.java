package java111.unit5.labs;

public class ConstructorLabTestDrive {
    public static void main(String[] args){
        ConstructorLab cons = new ConstructorLab();
        SubClassConstructorLab subCons = new SubClassConstructorLab();
    }
}