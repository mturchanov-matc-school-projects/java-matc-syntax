package java111.unit5.project;

/**
 *
 * Class represents a
 * processing for a single item
 *
 * @author mturchanov
 * 
 */
public class Order {
    private String customerName;
    private String productName;
    private int quantityOrdered;
    protected double total;
    private double unitPrice;

    /**
     *
     * initialize single item
     *
     * @param customerName Represents a customer name
     * @param productName Represents a product name
     * @param quantityOrdered Represents a quantiry of ordered items
     * @param unitPrice Represents a price per one item-unit
     */
    public Order(String customerName, String productName, int quantityOrdered, double unitPrice) {
        this.customerName = customerName;
        this.productName = productName;
        this.quantityOrdered = quantityOrdered;
        this.unitPrice = unitPrice;
    }

    /**
     *
     * Calculate a total charge for item
     *
     */
    public void calculateTotal() {
        total = quantityOrdered * unitPrice;
    }

    /**
     *
     * Set up for displaying an single 
     * order item
     *
     * @return Formatted string with all 
     * order-item information
     */
    @Override
    public String toString() {
        return String.format("Customer: %s%n" +
                "Item Ordered: %s%n" +
                "Unit Price: %.2f%n" +
                "Quantity Ordered: %d%n" +
                "Total: %.2f%n",customerName, productName, unitPrice,
                quantityOrdered, total);
    }
}
