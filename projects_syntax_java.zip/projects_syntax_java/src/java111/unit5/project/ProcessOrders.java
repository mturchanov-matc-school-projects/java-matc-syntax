package java111.unit5.project;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * The class process
 * different orders, and displays
 * info on them *
 *
 * @author mturchanov
 *
 */
public class ProcessOrders {
    private ArrayList<Order> orders = new ArrayList<>();

    /**
     *
     * Initialize orders to pseudo-'DB', order list
     *
     */
    public void getOrders() {
        Collections.addAll(orders, new Order("Mike Turchanov", "Gear", 8, 15.99),
                new WeightChargeOrder("Grzegorz Brzeczyszczykiewicz", "Hammer",2,10,50),
                new Order("Hanna Orataj", "Device", 3, 99.99),
                new WeightChargeOrder("Kalina Nalepa", "Wheel",4,77,63));
    }

    /**
     *
     * Calculate the total
     * based on order type
     *
     */
    public void run(){
        for (Order o : orders){
            o.calculateTotal();
        }
    }

    /**
     *
     * Displays orders
     *
     */
    public void displayOrders(){
        for (Order o : orders) {
            System.out.println(o);
            System.out.println();
        }
    }
}
