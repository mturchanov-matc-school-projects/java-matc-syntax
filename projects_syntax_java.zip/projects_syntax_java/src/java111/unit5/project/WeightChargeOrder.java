package java111.unit5.project;

/**
 *
 * Class represents an
 * order-item with a charge for  weight
 *
 * @author mturchanov
 *
 */
public class WeightChargeOrder extends Order {
    private int weight;
    private int charge;
    private double grandTotal;

    /**
     *
     * initialize single item
     *
     * @param customerName Represents a customer name
     * @param productName Represents a product name
     * @param quantityOrdered Represents a quantiry of ordered items
     * @param unitPrice Represents a price per one item-unit
     * @param weight Represents a weight of an item
     *
     */
    public WeightChargeOrder(String customerName, String productName, int quantityOrdered, double unitPrice, int weight) {
        super(customerName, productName, quantityOrdered, unitPrice);
        this.weight = weight;
        if(weight < 25) charge = 4;
        else if (weight >= 25 && weight < 45) charge = 5;
        else if(weight < 75) charge = 6;
        else charge = 7;
    }

    /**
     *
     * Calculating a total
     * including weight charge
     *
     */
    @Override
    public void calculateTotal() {
        super.calculateTotal();
        grandTotal = super.total + charge;
    }

    /**
     *
     * Format item to
     * display it if needed
     *
     *
     * @return Formatted String that represents
     * a single order for an item with all info
     * on it, including charge per weight
     */
    @Override
    public String toString() {
        String result =  super.toString();
        result += String.format("Weight: %d%nPlus a $%d handling charge%nGrand Total: %.2f",
                weight, charge, grandTotal);
        return result;
    }
}
