package java111.unit5.project;

/**
 *
 * Main output class
 *
 * @author mturchanov
 */
public class OrdersTestDrive {
    public static void main (String[] args) {
        ProcessOrders result = new ProcessOrders();
        result.getOrders();
        result.run();
        result.displayOrders();
    }
}
