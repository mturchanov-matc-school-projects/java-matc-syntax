public class FruityTestDrive{
    public static void main(String[] args){
        //lab3
        new Fruit().displayClassName();
        new Apple().displayClassName();
        new GrannySmith().displayClassName();

        //lab4
        Fruit fruit = new Fruit();
        Fruit apple = new Apple();
        Fruit gSmith = new GrannySmith();

        fruit.displayClassName();
        apple.displayClassName();
        gSmith.displayClassName();


        //fruit.wormSurprise();
        //apple.wormSurprise();
        //gSmith.wormSurprise();
        new GrannySmith().wormSurprise();

    }
}