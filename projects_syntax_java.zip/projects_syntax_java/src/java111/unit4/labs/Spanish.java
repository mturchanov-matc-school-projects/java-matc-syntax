/**
*
* This class provides the Spanish language translation for the ATM machine.
*
* @author chwalker
*
*/
public class Spanish implements Translatable {
    /**
    * The welcome string for the ATM machine.
    */
    public String getWelcome() {
        String welcome = "Bienvenido. Para comenzar, ingrese su tarjeta de cr�dito.";
        return welcome;
    }
    
    /**
    * The language prompt for the ATM machine.
    */
    public String getLanguagePrompt() {
        String prompt = "O bien, para cambiar de idioma, ingrese una de las siguientes selecciones (por n�mero):";
        return prompt;
    }

    /**
    * The quit menu item for the ATM machine.
    */
    public String getQuitMenuItem() {
        String prompt = "Dejar.";
        return prompt;
    }
}
