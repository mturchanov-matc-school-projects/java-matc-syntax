public class GrannySmith extends Apple {

      public void displayClassName(){
        System.out.println(this.getClass());
    }

    public void wormSurprise(){
        System.out.println("\"I am here to spoil your day\" @Mr.Worm");
    }
}