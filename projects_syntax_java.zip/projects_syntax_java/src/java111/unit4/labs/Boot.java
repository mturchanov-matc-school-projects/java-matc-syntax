public class Boot extends Footwear{
    private String type;
    private int footSize;

    public void setType(String type){
        this.type = type;
    }

    public void setFootSize(int footSize){
        this.footSize = footSize;
    }

    public String getType(String type){
        return type;
    }

    public int getFootSize(int footSize){
        return footSize;
    }


}