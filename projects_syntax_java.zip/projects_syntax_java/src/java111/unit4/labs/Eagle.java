public class Eagle extends Bird {

    @Override
    public void display() {
        System.out.println("Here am I, the Eagle.");
    }
    
}