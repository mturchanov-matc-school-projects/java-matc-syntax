public class CheckingAccount extends BankAccount {

    public CheckingAccount(String fullName, double balance) {
        super.setFullName(fullName);
        super.setBalance(balance);
        super.setId(BankAccount.idCounter++);
    }

    public double addInterest(double amount){
        return amount * 0.1;
    }

    @Override
    public void debitAccount(double debitAmount) {
        double balance = super.getBalance();
        double changedBalance = balance - (debitAmount - addInterest(debitAmount));
        super.setBalance(changedBalance);
    }

    @Override
    public void creditAccount(double creditAmount) {
        double balance = super.getBalance();
        double changedBalance = balance - (creditAmount - addInterest(creditAmount));
        super.setBalance(changedBalance);
    }

}