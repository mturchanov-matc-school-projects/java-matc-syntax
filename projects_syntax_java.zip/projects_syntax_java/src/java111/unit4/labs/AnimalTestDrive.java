public class AnimalTestDrive {
    public static void main (String[] args){
        //new Animal();
        Animal a = new Tiger();
        a.cry();
    }
}