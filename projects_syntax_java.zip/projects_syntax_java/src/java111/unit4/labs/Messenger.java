public class Messenger{

    public void outputMessage() {
        System.out.println("Output message");
    }
}