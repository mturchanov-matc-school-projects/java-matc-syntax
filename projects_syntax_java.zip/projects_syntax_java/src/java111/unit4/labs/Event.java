public interface Event {
    abstract void display();
}