/**
 * 
 * Create an abstract class named Animal and place it in your project4/labs directory.
 * Add a display method to the abstract class that simply identifies itself.
 * Create a test drive class for the abstract class. Attempt to instantiate an object of the Animal class to see what the compiler will do.
 * Now create another class that subclasses the abstract class. You won’t need any variables or methods in this class.
 * Change the test drive class so that it instantiates the subclass. Leave the type to be the superclass. Compile and test.
 * 
 * 
 */

abstract class Animal {

    public void cry(){
        System.out.println("Who am I?");
    }
}