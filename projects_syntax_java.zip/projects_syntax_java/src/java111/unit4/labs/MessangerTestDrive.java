public class MessangerTestDrive {
    public static void main(String[] args){
        Messenger mssnger = new Messenger();
        SpanishMessenger sMessanger = new SpanishMessenger();

        mssnger.outputMessage();
        sMessanger.outputMessage();
    }
}