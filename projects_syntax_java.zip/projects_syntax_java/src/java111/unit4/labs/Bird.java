/**
 * 
 * Create an abstract class named Bird and place it in your project4/labs directory.
 * Add an abstract display method to the class.
 * Create a subclass of the abstract superclass. Don’t add any methods and attempt to compile the class to see that the compiler will do.
 * Next, add the method to the subclass that is the same as the abstract method in the superclass. Compile the class again.
 * Create a test drive class and instantiate an object from the subclass and call the display method.
 * 
 * 
 * 
 * 
 */


abstract class Bird {
    abstract void display();
    
}