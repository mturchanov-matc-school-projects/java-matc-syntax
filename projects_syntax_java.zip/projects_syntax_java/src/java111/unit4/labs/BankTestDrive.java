import java.util.*;

public class BankTestDrive {
    public static void main(String[] args){
        List<BankAccount> bankAccounts= new ArrayList<>();

        BankAccount checkingAccount1 = new CheckingAccount("Mike Turchanov", 400.50);
        BankAccount checkingAccount2 = new CheckingAccount("Bill Cornelly", 100.50);

        BankAccount autoLounAccount1 = new AutoLoan("Kripp Gussov", 9999.99);
        BankAccount autoLounAccount2 = new AutoLoan("Viktoria Goldman", 1123.23);

        Collections.addAll(bankAccounts,checkingAccount1,checkingAccount2,autoLounAccount1,autoLounAccount2);

        for(BankAccount acc : bankAccounts){
            int id = acc.getId();
            double balance = acc.getBalance();
            String name = acc.getFullName();

            if(id % 2 == 0){
                acc.creditAccount(50.5);
                System.out.println("-----------------");
                System.out.printf("ID: %d%nFULL NAME: %s%nBALANCE: %.2f%n",id,name,balance);
                System.out.println("-----------------\n");
            } else{
                acc.debitAccount(44.5);
                System.out.println("-----------------");
                System.out.printf("ID: %d%nFULL NAME: %s%nBALANCE: %.2f%n",id,name,balance);
                System.out.println("-----------------\n");

            }
        }
    }
}