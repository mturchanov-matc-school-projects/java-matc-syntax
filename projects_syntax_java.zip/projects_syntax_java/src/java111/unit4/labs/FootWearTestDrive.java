public class FootWearTestDrive {
    public static void main(String[] args) {
      Boot boot = new Boot();
      boot.setColor("blue");
      boot.setFootSize(42);
      boot.setIsCool(false);
      boot.setPrice(10.5);
      boot.setType("sporting");
      boot.displayFootWear();
    }
}