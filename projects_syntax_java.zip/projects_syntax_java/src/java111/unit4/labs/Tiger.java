public class Tiger extends Animal {
    
    public void cry (){
        System.out.println("Akella has missed!");
    }
}