import java.util.*;

/**
*
* The class that controls the main menu of the ATM machine. NOTE TO ADD A NEW LANGUAGE, YOU DON'T
* HAVE TO UNDERSTAND THIS CLASS ASIDE FROM THE SIMPLE addLanguageBundle() METHOD.
*
* @author chwalker
*
*/
public class MainMenu {
    private int currentLanguageNum = 0;
    private ArrayList<LanguageBundle> languages = new ArrayList<LanguageBundle>();

    /**
    * The constructor. It adds the default English language.
    */
    public MainMenu() {
        LanguageBundle englishBundle = new LanguageBundle();
        englishBundle.setLanguageName("English");
        English english = new English();
        englishBundle.setLanguageObject(english);

        languages.add(englishBundle);
    }
    
    /**
    * The method to add a new language to the menu.
    *
    * @param languageBundle The new language, with the language name and the object containing the translated strings.
    *
    */
    public void addLanguageBundle(LanguageBundle languageBundle) {
        languages.add(languageBundle);
    }
    
    /**
    * The method that displays the menu and handles input.
    */
    public void prompt() {
        // Default to English.
        Translatable currentLanguage = languages.get(currentLanguageNum).getLanguageObject();
        

        // Loop until the user selects "quit".
        boolean quit = false;
        while (!quit) {
            System.out.println();
            System.out.println();

            String welcome = currentLanguage.getWelcome();
            System.out.println(welcome);
            System.out.println();

            String switchLanguagePrompt = currentLanguage.getLanguagePrompt();
            System.out.println(switchLanguagePrompt);
            System.out.println();

            // Display a menu option for each language.
            for (int languageIt = 0; languageIt < languages.size(); ++languageIt) {
                String languageName = languages.get(languageIt).getLanguageName();
                Integer menuNumber = languageIt + 1;
                System.out.println(menuNumber.toString() + ". " + languageName);
            }
        
            // Display a menu option for the word "quit".
            Integer menuNumber = languages.size() + 1;
            System.out.println(menuNumber.toString() + ". " + currentLanguage.getQuitMenuItem());
        
            // Get the menu item number from the user.
            int selectionNum = -1;
            while ((selectionNum < 0) || (selectionNum > languages.size())) {
                String selection = System.console().readLine();
                int number = Integer.parseInt(selection);
                selectionNum = number - 1;
            }

            if (selectionNum == languages.size()) {
                // The user selected "quit", so quit.
                quit = true;
            }
            else {
                // The user decided to change the language, so change the language.
                currentLanguageNum = selectionNum;
                currentLanguage = languages.get(currentLanguageNum).getLanguageObject();
            }
        }
    }
}
