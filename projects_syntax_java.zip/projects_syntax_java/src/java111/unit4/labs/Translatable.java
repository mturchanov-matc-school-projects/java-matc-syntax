/**
*
* The interface that serves as the intermediary between the main menu and the class representing the language.
*
* @author chwalker
*
*/
public interface Translatable {
    /**
    * The welcome string for the ATM machine.
    */
    public abstract String getWelcome();
    
    /**
    * The language prompt for the ATM machine.
    */
    public abstract String getLanguagePrompt();
    
    /**
    * The quit menu item for the ATM machine.
    */
    public abstract String getQuitMenuItem();
}
