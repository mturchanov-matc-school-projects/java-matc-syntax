/**
*
* This class provides my mom's Southern language translation for the ATM machine.
*
* @author chwalker
*
*/
public class MyMomsSouthernAccent implements Translatable {
    /**
    * The welcome string for the ATM machine.
    */
    public String getWelcome() {
        String welcome = "Well now, how sweet y'all look. If you want to get yourself some money, just go on ahead and put your debit card in the little slot.";
        return welcome;
    }
    
    /**
    * The language prompt for the ATM machine.
    */
    public String getLanguagePrompt() {
        String prompt = "If you want to switch languages, I'll miss you, but go on ahead and enter one of the following selections (by number):";
        return prompt;
    }
    
    /**
    * The quit menu item for the ATM machine.
    */
    public String getQuitMenuItem() {
        String prompt = "Go on home now.";
        return prompt;
    }
}
