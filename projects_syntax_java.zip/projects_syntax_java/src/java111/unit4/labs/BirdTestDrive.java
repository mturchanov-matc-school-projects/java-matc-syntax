public class BirdTestDrive {
    public static void main(String[] args){
        Bird b = new Eagle();
        b.display();
    }
}