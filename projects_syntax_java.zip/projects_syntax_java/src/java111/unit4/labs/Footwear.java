public class Footwear{
    private String color;
    private boolean isCool;
    private double price;

    public void setColor(String color){
        this.color = color;
    }

    public void setIsCool(boolean isCool){
        this.isCool = isCool;
    }

    public void setPrice(double price){
        this.price = price;
    }

    public String getColor(){
        return color;
    }

    public boolean getIsCool (){
        return isCool;
    }

    public double getPrice(){
        return price;
    }

    public void displayFootWear() {
        System.out.printf("The %5s%nColor: %5s%nIs it cool: %5b"
                + "%nPrice: %5.2f",this.getClass(),color,String.valueOf(isCool),price);
    }
}