public abstract class BankAccount {
    protected static int idCounter = 1;
    private double balance;
    private int id;
    private String fullName;

    public abstract void debitAccount(double debitAmount);

    public abstract void creditAccount(double creditAmount);

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}