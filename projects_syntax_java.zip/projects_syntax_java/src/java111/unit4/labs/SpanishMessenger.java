public class SpanishMessenger extends Messenger {

    @Override
    public void outputMessage(){
        System.out.println("Spanish output message");
    }
}