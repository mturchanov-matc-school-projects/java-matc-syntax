public class AutoLoan extends BankAccount {

    public AutoLoan(String fullName, double balance) {
        super.setFullName(fullName);
        super.setBalance(balance);
        super.setId(BankAccount.idCounter++);
    }

    public double deductInterest(double amount){
        return amount * 0.2;
    }

    @Override
    public void debitAccount(double debitAmount) {
        double balance = super.getBalance();
        double changedBalance = balance - (debitAmount + deductInterest(debitAmount));
        super.setBalance(changedBalance);
    }

    @Override
    public void creditAccount(double creditAmount) {
        double balance = super.getBalance();
        double changedBalance = balance - (creditAmount + deductInterest(creditAmount));
        super.setBalance(changedBalance);
    }


}