/**
*
* For simplicity, this class associates the object representing a language with the menu item name for that language.
*
* @author chwalker
*
*/
public class LanguageBundle {    
    private String languageName;
    // The object with the Spanish or English or whatever language strings. Note that we don't have
    // to write code to refer to Spanish and English and other languages; we just refer to the type
    // of Translatable.
    private Translatable languageObject;

    /**
    * Sets the name of the language.
    *
    * @param name The name of the language.
    *
    */
    public void setLanguageName(String name) {
        languageName = name;
    }
    
    /**
    * Gets the name of the language.
    *
    * @return The name of the language.
    *
    */
    public String getLanguageName() {
        return languageName;
    }
    
    /**
    * Sets the object with the methods to retrieve the translated strings.
    *
    * @param name The name of the language.
    *
    */
    public void setLanguageObject(Translatable object) {
        languageObject = object;
    }
    
    /**
    * Gets the object with the methods to retrieve the translated strings.
    *
    * @return The name of the language.
    *
    */
    public Translatable getLanguageObject() {
        return languageObject;
    }
}
