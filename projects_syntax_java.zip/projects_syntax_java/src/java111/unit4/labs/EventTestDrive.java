import java.util.*;

public class EventTestDrive {
    public static void main (String[] args){
        Event event = new Meeting();
        event.display();
        List<Event> eventsList = new ArrayList<>(Arrays.asList(event,new Marathon(),new Meeting(),new Marathon()));

        for(Event e : eventsList){
            e.display();
        }
    }
}