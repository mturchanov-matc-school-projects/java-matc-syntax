public class Apple extends Fruit {
      public void displayClassName(){
        System.out.println(this.getClass());
    }
}