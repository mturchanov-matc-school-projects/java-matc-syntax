public class Marathon implements Event {

    @Override
    public void display() {
        System.out.println("Ahead to Athens!");
    }
    
}