/**
* This class represents the display of an ATM machine.
*
* @author chwalker
*
*/
public class ATMDisplay {
    /**
    * The entry point for the application.
    *
    * @param args The command-line arguments.
    *
    */
    public static void main(String[] args) {
        // Instantiate the menu object.
        MainMenu menu = new MainMenu();
        
        // Create the Spanish language bundle and add it to the menu.
        Spanish spanish = new Spanish();
        // We have an object called spanish that has the Spanish language translations. However,
        // we want to cast it to the interface so that it's easier for us to use. That is, if we
        // can refer to every language as a type of Translatable, we don't have to keep writing
        // code that has to know the type of every language now and in the future. If you look at
        // the source code for LanguageBundle, you won't find code that refers specifically to
        // Spanish, or English, or any language. It simply refers to the Translatable type.
        Translatable spanishTranslatable = (Translatable)spanish;
        LanguageBundle spanishBundle = new LanguageBundle();
        spanishBundle.setLanguageName("Spanish");
        spanishBundle.setLanguageObject(spanishTranslatable);
        menu.addLanguageBundle(spanishBundle);
        
        // Create my mom's language bundle and add it to the menu.
        MyMomsSouthernAccent mom = new MyMomsSouthernAccent();
        Translatable momTranslatable = (Translatable)mom;
        LanguageBundle momBundle = new LanguageBundle();
        momBundle.setLanguageName("My Mom's Southern Accent");
        momBundle.setLanguageObject(momTranslatable);
        menu.addLanguageBundle(momBundle);
        // Start the menu.
        menu.prompt();
    }
}
