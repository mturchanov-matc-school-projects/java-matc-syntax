/**
*
* This class provides the English language translation for the ATM machine.
*
* @author chwalker
*
*/
public class English implements Translatable {
    /**
    * The welcome string for the ATM machine.
    */
    public String getWelcome() {
        String welcome = "Welcome. To begin, please enter your debit card.";
        return welcome;
    }
    
    /**
    * The language prompt for the ATM machine.
    */
    public String getLanguagePrompt() {
        String prompt = "Or, to switch languages, enter one of the following selections (by number):";
        return prompt;
    }
    
    /**
    * The quit menu item for the ATM machine.
    */
    public String getQuitMenuItem() {
        String prompt = "Quit.";
        return prompt;
    }
}
