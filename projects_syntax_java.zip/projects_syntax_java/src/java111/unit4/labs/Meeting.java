/**
 * This will not take us deep into creating an interface. In fact, it only takes us through some of the mechanics.
 *  Really showing the details and the usefulness would take us beyond the scope of a lab.
 *
 * Create an interface called Event with an abstract display method. Save it and compile it.
 * Create a class, Meeting that implements the interface.
 * Make a test drive class.
 * Instantiate an object from the class.
 * Instantiate an object with the type of the interface. This won’t compile, why? Now fix it.
 * Next, create another class, Marathon that also implements the interface.
 * Add an ArrayList to the test drive class. Add new instances of each class to the ArrayList. Loop through the array list and cast each object to the type of the interface and call the display method.
 * 
 */




public class Meeting implements Event{

    @Override
    public void display(){
        System.out.println("Crowd, noice, boreness");
    }
}