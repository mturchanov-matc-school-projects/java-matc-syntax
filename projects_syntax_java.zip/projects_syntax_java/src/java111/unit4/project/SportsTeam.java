import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.util.Date;

/**
 *
 * This class represents
 * school sport team
 *
 * @author mturchanov
 *
 */
public class SportsTeam extends ExtraCurricularActivity {
    private Date upcomingGame;
    private boolean playAtHome;
    private String mascot;

    /**
     *
     * Constructor
     *
     * @param name The name of the sport team
     * @param upcomingGame The date of an upcoming game
     * @param playAtHome Whether a team will play at home or not
     * @param mascot The name of a sport teams's mascot
     * @throws ParseException  Signals that an error has been reached unexpectedly
     *   while parsing.
     *
     */
    public SportsTeam(String name, String upcomingGame, boolean playAtHome, String mascot) throws ParseException {
        if(!upcomingGame.matches("(0?[1-9]|0?1[0-2]) (\\d{2}) (\\d{4})")) {
            throw new DateTimeException("Wrong date format/ MM DD YYYY is the right way");
        }

        SimpleDateFormat format = new SimpleDateFormat("mm dd yyyy");
        super.setName(name);
        this.upcomingGame = format.parse(upcomingGame);
        this.playAtHome = playAtHome;
        this.mascot = mascot;
    }

    /**
     *
     * Represents a sport team;
     * to get all information about it
     *
     * @return The string that include all information on
     * a sport team
     *
     */
    @Override
    public String toString() {
        return String.format(">\tSport Team: %s%n>\tUpcoming Game: %tD%n>\tMascot: %s%n>\t"
                + "Playing at Home: %b%n\t", super.getName(), upcomingGame, mascot, playAtHome);
    }
}

