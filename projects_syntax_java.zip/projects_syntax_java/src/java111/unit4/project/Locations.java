/**
 *
 * This enum represents
 * a school locations/sectors
 *
 * @author mturchanov
 * 
 */
public enum Locations {
    MIDDLE_SCHOOL,
    HIGH_SCHOOL,
    FOOTBALL_FIELD
}
