import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * This class represents
 * games schedule of
 * sporting (school)teams
 *
 * @author mturchanov
 *
 */
public class GameSchedule {
    private List<SportsTeam> teams= new ArrayList<>();

    /**
     *
     * Constructor
     *
     * @param teams Sets the sporting teams
     *
     */
    public GameSchedule(List<SportsTeam> teams) {
        this.teams = teams;
    }

    /**
     *
     * Constructor
     *
     */
    public GameSchedule() {}

    /**
     *
     * Add a team to teams that
     * will play
     *
     * @param team One team that is added
     */
    public void addTeam(SportsTeam team){
        teams.add(team);
    }

    /**
     *
     * Add a team or teams
     * that will play
     *
     * @param teams Team or teams that are added
     *
     */
    public void addTeam(SportsTeam...teams){
        this.teams.addAll(Arrays.asList(teams));
    }

    /**
     *
     * Displays the information on each
     * sporting team that will play
     *
     */
    public void display(){
        System.out.println("================================================"
                + "\nSPORT TEAMS INFO:\n");
        for(SportsTeam team : teams) {
            System.out.println(team);
        }
    }
}


