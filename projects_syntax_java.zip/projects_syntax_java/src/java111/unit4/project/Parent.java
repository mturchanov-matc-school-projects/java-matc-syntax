/**
 *
 * Represents a parents
 * of a school students
 *
 * @author mturchanov
 *
 */
public class Parent extends Person {}
