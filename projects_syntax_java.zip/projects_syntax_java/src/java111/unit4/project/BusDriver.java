/**
 *
 * This class represents
 * a group of school bus drivers
 *
 * @author mturchanov
 * 
 */
public class BusDriver extends Person {
}
