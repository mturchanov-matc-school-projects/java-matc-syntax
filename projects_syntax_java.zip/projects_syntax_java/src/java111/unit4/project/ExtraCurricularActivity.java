/**
 *
 * This class represents an extra curricular
 * activity(club)
 *
 * @author mturchanov
 *
 */
public class ExtraCurricularActivity {
    private String name;
    private String leader;
    private int studentNumber;

    /**
     *
     * Constructor
     *
     */
    public ExtraCurricularActivity() {}

    /**
     *
     * Constructor
     *
     * @param name that represents a name of a club
     * @param leader that represents a leader of a club
     * @param studentNumber that represents a number of
     * students that are in a club
     */
    public ExtraCurricularActivity(String name, String leader, int studentNumber) {
        this.name = name;
        this.leader = leader;
        this.studentNumber = studentNumber;
    }

    /**
     *
     * Retrives full infromation on
     * extra ordinary activity
     *
     * @return String formatted data about object(activity)
     *
     */
    @Override
    public String toString() {
        return String.format("activity: %s, Leader: %s, Student Number: %d",name,leader,studentNumber);
    }

    /**
     * Gets the name of the club
     *
     * @return The name of the club
     *
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the club
     *
     * @param name The name of the club
     *
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * Gets the leader of a club
     *
     * @return the leader of a club
     *
     */
    public String getLeader() {
        return leader;
    }

    /**
     *
     * Sets the leader of a club
     *
     * @param leader The leader of a club
     */
    public void setLeader(String leader) {
        this.leader = leader;
    }

    /**
     *
     * Gets the student number in a club
     *
     * @return The students number
     *
     */
    public int getStudentNumber() {
        return studentNumber;
    }

    /**
     *
     * Sets the student number that are in the club
     *
     * @param studentNumber The student number in the club
     *
     */
    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }
}

