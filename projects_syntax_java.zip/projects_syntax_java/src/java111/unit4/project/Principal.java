/**
 *
 * This class represents
 * a principal of a school
 *
 * @author mturchanov
 *
 */
public class Principal extends Person implements Badgeable  {

    /**
     *
     * Overriden Badgeable.allowEntry(Locations location)
     * that check if the student can enter on
     * a specific location
     *
     * @param location Location where badge-owener try to enter
     * @return The decision on whether a principal can enter or not
     *
     */
    public boolean allowEntry(Locations location) {
        return true;
    }
}
