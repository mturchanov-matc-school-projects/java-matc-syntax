/**
 *
 * This class represents
 * elementary students
 *
 * @author mturchanov
 *
 */
public class ElementaryStudents extends Student {
    private int busNumber;

    public ElementaryStudents() {}

    /**
     *
     * Constructor
     *
     *
     * @param id The id number of the elementary student
     * @param name The name of the elementary student
     * @param teacher The teacher of the elementary student
     * @param schoolName The name of the school where elementary students is studying
     * @param GPA The GPA of the elementary student
     * @param busNumber The bus number that the studenet uses
     *
     */
    public ElementaryStudents(int id, String name, String teacher, String schoolName, double GPA, int busNumber) {
        this.busNumber = busNumber;
        super.setName(name);
        super.setId(id);
        super.setTeacher(teacher);
        super.setGPA(GPA);
        super.setSchoolName(schoolName);
    }

    /**
     *
     * Gets the bus number
     *
     * @return the bus number
     */
    public int getBusNumbers() { return busNumber; }

    /**
     *
     * Sets the bus number of a student
     *
     * @param busNumbers The bus number
     */
    public void setBusNumbers(int busNumbers) {
        this.busNumber = busNumbers;
    }

    /**
     *
     * Display all data
     * regarding the elementary student     *
     *
     */
    public void displayReportCard() {
        System.out.printf(super.getStudentInfoFormat() + "%n>\tBus Number: %d%n",
                super.getId(), super.getName(), super.getSchoolName(), super.getGPA(), super.getActivities(), super.getTeacher(), busNumber);
        System.out.println("-----------------------------------------------------------");
    }
}
