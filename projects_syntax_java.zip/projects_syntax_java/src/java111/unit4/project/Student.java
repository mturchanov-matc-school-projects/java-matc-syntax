import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * Represents a student
 *
 * @author mturchanov
 *
 */
public abstract class Student extends Person {

    private double GPA;
    private List<ExtraCurricularActivity> activities = new ArrayList<>();
    private String teacher;
    private String studentInfoFormat = ">\tStudent ID: %d%n>\tStudent Name: %s%n>\t"
            + "School Name: %s%n>\tGrade Point Average: %.2f%n>\t"
            + "Activities: %s%n>\tTeacher: %s";

    /**
     *
     * Gets the GPA of a student
     *
     * @return the GPA of a student
     */
    public double getGPA() {
        return GPA;
    }

    /**
     *
     * Sets the GPA of a student
     *
     * @param GPA The GPA
     */
    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    /**
     *
     * Gets the formatted general
     * student information
     *
     * @return The string with formatted general
     * student information
     */
    public String getStudentInfoFormat() {
        return studentInfoFormat;
    }

    /**
     *
     * Sets the formatted general
     * student information
     *
     * @param studentInfoFormat The formatted general student information
     *
     */
    public void setStudentInfoFormat(String studentInfoFormat) {
        this.studentInfoFormat = studentInfoFormat;
    }

    /**
     *
     * Gets the all extra curricular activities
     * of a student
     *
     * @return The all extra curricular activities
     * that a student has
     *
     */
    public String getActivities() {

        if(activities.size() == 0) return "none";
        StringBuilder sb = new StringBuilder();

        for(ExtraCurricularActivity club : activities){
            sb.append("\n\t  >  ").append(club);
        }
        return sb.toString();
    }

    /**
     *
     * Sets list of extraordinary activities of a student
     *
     * @param activities List of extra ordinary activities
     *
     */
    public void setActivities(List<ExtraCurricularActivity> activities) { this.activities = activities; }

    /**
     *
     * Adds extra ordinary activities to
     * to a student activities
     *
     * @param clubs Activity(ies) that are added to student's activities
     *
     */
    public void addActivities(ExtraCurricularActivity...clubs){
        Collections.addAll(activities, clubs);
    }

    /**
     *
     * Gets the teacher name
     *
     * @return The teacher name
     *
     */
    public String getTeacher() {
        return teacher;
    }

    /**
     *
     * Sets the name of the student's teacher
     *
     * @param teacher The teacher name
     *
     */
    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    /**
     *
     * Display all information on
     * a student
     *
     */
    public abstract void displayReportCard();
}

