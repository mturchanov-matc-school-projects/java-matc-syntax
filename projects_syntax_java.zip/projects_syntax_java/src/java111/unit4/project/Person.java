/**
 *
 * Represents a person
 * that is related to a school
 *
 * @author mturchanov
 *
 */
public class Person {
    private String name;
    private int id;
    private String schoolName;

    /**
     *
     * Gets the name of a person
     *
     * @return The name of a person
     *
     */
    public String getName() {
        return name;
    }

    /**
     *
     * Sets the name of a person
     *
     * @param name The name of the person
     *
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * Gets the ID of a person
     *
     * @return The ID of a person
     */
    public int getId() {
        return id;
    }

    /**
     *
     * Sets the ID of a person
     *
     * @param id The ID pf the person
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * Retrieves the school name
     * of a person
     *
     * @return The school name
     */
    public String getSchoolName() {
        return schoolName;
    }

    /**
     *
     * Sets the school name
     * of a person
     *
     * @param schoolName A school name
     */
    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }
}

