/**
 *
 * This class represents a high
 * school students
 *
 * @author mturchanov
 *
 */
public class HighSchoolStudents extends Student implements Badgeable {
    private int parkingIds;

    /**
     *
     * Gets the parking id
     * of a high school student
     *
     * @return The parking id
     */
    public int getParkingIds() {
        return parkingIds;
    }

    /**
     *
     * Constructor
     *
     */
    public HighSchoolStudents() {}

    /**
     *
     * Constructor
     *
     * @param id The id of the high schoold student
     * @param name The name of the high school student
     * @param teacher The teacher of the high school student
     * @param schoolName The school name where high school student studies
     * @param GPA The GPA of the high school student
     * @param parkingIds The parking ID of the high school student
     *
     */
    public HighSchoolStudents(int id, String name, String teacher, String schoolName, double GPA, int parkingIds) {
        this.parkingIds = parkingIds;
        super.setName(name);
        super.setId(id);
        super.setTeacher(teacher);
        super.setGPA(GPA);
        super.setSchoolName(schoolName);
    }

    /**
     *
     * Sets the parking ID
     * of the high school student
     *
     * @param parkingIds
     *
     */
    public void setParkingIds(int parkingIds) {
        this.parkingIds = parkingIds;
    }


    /**
     *
     * Displays the full information
     * on a high school student
     *
     */
    public void displayReportCard() {
        System.out.printf(super.getStudentInfoFormat() + "%n>\tParking ID: %d%n",
                super.getId(), super.getName(), super.getSchoolName(), super.getGPA(),
                super.getActivities(), super.getTeacher(), parkingIds);
        System.out.println("-----------------------------------------------------------");
    }

    /**
     *
     * Overriden Badgeable.allowEntry(Locations location)
     * that check if the student can enter on
     * a specific location
     *
     * @param location Location where badge-owener try to enter
     * @return The decision on whether a high school
     * student can enter or not
     *
     */
    public boolean allowEntry(Locations location) {
        return Locations.HIGH_SCHOOL == location || Locations.FOOTBALL_FIELD == location;
    }
}

