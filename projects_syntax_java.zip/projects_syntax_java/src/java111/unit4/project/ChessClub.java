/**
 *
 * This class represents
 * a chess club that is
 * a part of academic clubs
 *
 */
public class ChessClub extends AcademicClub {
    private String chessGuru;

    /**
     *
     * Gets the chess guru
     * of the chess club
     *
     * @return The Guru of a Chess Club
     */
    public String getChessGuru() {
        return chessGuru;
    }

    /**
     *
     *
     * Sets the Guru of the Chess Club
     *
     * @param chessGuru The Chess Guru of Chess Club
     *
     */
    public void setChessGuru(String chessGuru) {
        this.chessGuru = chessGuru;
    }
}
