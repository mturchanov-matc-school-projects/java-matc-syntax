import java.util.ArrayList;
import java.util.List;

/**
 *
 * This class represents
 * report cards
 *
 * @author mturchanov
 *
 */
public class StudentReportCards {
    private List<Student> students = new ArrayList<>();

    /**
     *
     * Adds students to a
     * student report list
     *
     * @param students
     */
    public void addStudent(Student ...students){
        for(Student student : students) {
            this.students.add(student);
        }

    }

    /**
     *
     * Displays all information
     * on a student that is in a
     * student report list
     *
     */
    public void printAllReportCards(){
        System.out.println("================================================"
                + "\nSTUDENTS INFORMATION:\n");

        for(Student student : students){
            student.displayReportCard();
        }
    }
}

