/**
 *
 * This class represents
 * the academic school club
 *
 * @author mturchanov
 *
 */
public class AcademicClub extends ExtraCurricularActivity {
    private boolean isCreditEligible;

    /**
     *
     * Gets/checks if academic club
     * is credit eligible
     *
     * @return The check if a club is
     * credit eligible
     *
     */
    public boolean isCreditEligible() {
        return isCreditEligible;
    }

    /**
     *
     * Sets the eligibility
     * of a club for credits
     *
     * @param creditEligible The credit elegibility of a club
     *
     */
    public void setCreditEligible(boolean creditEligible) {
        isCreditEligible = creditEligible;
    }
}

