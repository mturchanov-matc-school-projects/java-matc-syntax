
/**
 *
 * This class represents
 * a middle school student
 *
 * @author mturchanov
 *
 */
public class MiddleScoolStudents extends Student implements Badgeable {
    private int lockerNumbers;

    public MiddleScoolStudents() {}

    /**
     *
     * Constructor
     *
     * @param id The ID of the middle school student
     * @param name The name of the middle school student
     * @param teacher The teacher of the middle school student
     * @param schoolName The school name where a middle school student
     * studies
     * @param GPA The GPA of the middle school student
     * @param lockerNumbers The locker number of the middle school student
     *
     */
    public MiddleScoolStudents(int id, String name, String teacher, String schoolName, double GPA, int lockerNumbers) {
        this.lockerNumbers = lockerNumbers;
        super.setName(name);
        super.setId(id);
        super.setTeacher(teacher);
        super.setGPA(GPA);
        super.setSchoolName(schoolName);
    }

    /**
     *
     * Gets the locker number
     *
     * @return The locker number of the middle school student
     */
    public int getLockerNumbers() {
        return lockerNumbers;
    }

    /**
     *
     * Sets the locker number of the middle school
     * student
     *
     * @param lockerNumbers
     *
     */
    public void setLockerNumbers(int lockerNumbers) {
        this.lockerNumbers = lockerNumbers;
    }

    /**
     *
     * Display all information on a
     * middle school student
     *
     */
    public void displayReportCard() {
        System.out.printf(super.getStudentInfoFormat() + "%n>\tLocker Number: %d%n",
                super.getId(), super.getName(), super.getSchoolName(), super.getGPA(),
                super.getActivities(), super.getTeacher(), lockerNumbers);
        System.out.println("-----------------------------------------------------------");
    }

    /**
     *
     * Overriden Badgeable.allowEntry(Locations location)
     * that check if the student can enter on
     * a specific location
     *
     * @param location Location where badge-owner try to enter
     * @return The decision on whether a middle school student
     * can enter or not
     *
     */
    public boolean allowEntry(Locations location) {
        return Locations.MIDDLE_SCHOOL == location;
    }
}

