/**
 *
 * This class represents
 * a badge reader
 *
 * @author mturchanov
 */
public class BadgeReader {

    /**
     *
     * Checking if a provided
     * badge has the access to
     * a provided location
     *
     * @param location Location that is trying to access via the badge
     * @param badge Badge that is used to enter on specific location
     * @return Decision if access is approved or denied
     *
     */
    public boolean swipe(Locations location, Badgeable badge){
        boolean canEnter = badge.allowEntry(location);

        if(canEnter) System.out.println("Entry allowed");
        else System.out.println("Entry denied");

        return canEnter;
    }
}
