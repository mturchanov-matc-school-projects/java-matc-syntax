import java.text.ParseException;

/**
 * The entry point of the application.
 *
 * @param args The command-line arguments.
 * @author mturchanov
 *
 */
public class Project4TestDrive {
    public static void main(String[] args) throws ParseException {

        //set up schedule for sport teams 
        GameSchedule schedule = new GameSchedule();
        SportsTeam redSox = new SportsTeam("Red Sox", "10 14 2020", true, "Red sox");
        SportsTeam durhamBulls = new SportsTeam("Durham Bulls", "07 20 2020", false, "Blue Bull");
        SportsTeam milkmen = new SportsTeam("Milwaukee Milkmen", "11 30 2020", true, "Box of Milk");
        schedule.addTeam(redSox,durhamBulls,milkmen);

        schedule.display();

        //set up school activities
        ExtraCurricularActivity sw = new ExtraCurricularActivity("Swimming Club", "Chad Willson", 25);
        ExtraCurricularActivity box = new ExtraCurricularActivity("Box", "Voland Yutro", 10);
        ExtraCurricularActivity dancing = new ExtraCurricularActivity("Dance", "Hanna Hulajnoga", 30);

        //set up students
        Student elem1 = new ElementaryStudents(1,"Kasia Brzeczysczykiewicz", "Lepszy Nauczyciel","School#44", 2.2, 123 );
        elem1.addActivities(sw,box);
        Student elem2 = new ElementaryStudents(2,"Zosia Miodowa", "Gorszy Nauczyciel","School#24", 3.2, 124 );
        Student elem3 = new ElementaryStudents(3,"Kalina Jedresiuk", "Wladyslaw Siary","School#4", 3.7, 124 );
        elem3.addActivities(sw,dancing);

        Student mid1 = new MiddleScoolStudents(4,"Kalina Jedresiuk", "Wladyslaw Siary","School#4", 3.7, 324 );
        mid1.addActivities(sw,box,dancing);
        Student mid2 = new MiddleScoolStudents(5,"Pitrek Rudy", "Wladyslaw Bialy","School#41", 2.7, 214 );

        Student high1 = new HighSchoolStudents(6,"Michal Wkurzony", "Wladyslaw Siary","School#24", 3.1, 12413 );
        Student high2 = new HighSchoolStudents(7,"Janek Zmeczony", "Lepszy Nauczyciel","School#44", 2.1, 12412 );
        high2.addActivities(sw);

        //adding students to student report cards
        StudentReportCards studentCards = new StudentReportCards();
        studentCards.addStudent(elem1,elem2,elem3,mid1,mid2,high1,high2);
        studentCards.printAllReportCards();

        //similate badge verification process
        BadgeReader verificationBadge = new BadgeReader();
        Principal myPrincipal = new Principal();

        verificationBadge.swipe(Locations.FOOTBALL_FIELD,myPrincipal);
        verificationBadge.swipe(Locations.HIGH_SCHOOL, (Badgeable) mid1);
        verificationBadge.swipe(Locations.HIGH_SCHOOL, (Badgeable) high1);
        //verificationBadge.swipe(Locations.HIGH_SCHOOL,elem1);

    }

}

