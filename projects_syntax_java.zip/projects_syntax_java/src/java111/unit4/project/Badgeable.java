/**
 *
 * This interface represents
 * people/objects that can have a badge
 *
 */
public interface Badgeable {

    /**
     *
     * Checking if a badge
     * has entry access
     * on a specific location
     *
     * @param location Location where badge-owener try to enter
     * @return Boolean value if access is approved or denied
     *
     */
    boolean allowEntry(Locations location);
}
