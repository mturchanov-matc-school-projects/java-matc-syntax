public class MakeListWordsTestDrive{
    public static void main(String[] args){
        ProcessWords result = new ProcessWords();
        result.processWords();
    }
}