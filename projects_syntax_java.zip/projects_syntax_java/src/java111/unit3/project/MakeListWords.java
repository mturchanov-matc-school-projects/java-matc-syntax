import java.util.*;

public class MakeListWords{
    private ArrayList<String> inputWords = new ArrayList<>();;
    private boolean wordsAreFun = true;
    private List<String> keywords = new ArrayList<>(Arrays.asList("hello","bye","name","word"));
    private List<String> matches = new ArrayList<>();

    public void addWords(){
        InputHelper input = new InputHelper();
        
        String newWord = "";                
        newWord = input.getUserInput("Enter a new word or say NO!");
        if(!newWord.isEmpty()){
            if(!inputWords.contains(newWord) && !newWord.toLowerCase().equals("no")) {
                inputWords.add(newWord);
            }
            if(keywords.contains(newWord) && !matches.contains(newWord)) matches.add(newWord);
            if(newWord.toLowerCase().equals("no")) wordsAreFun = false;
        }       
        
    }

    public boolean getWordsAreFun(){
        return wordsAreFun;
    }

    public void getResults() {
        Collections.sort(inputWords);
        System.out.println("Here your words in alphabetical order: ");
        for(String el : inputWords){
            System.out.println("\t*" + el);
        }
        System.out.println("\nAlso,you got some matches on keywords: ");
        if(matches.size() == 0) System.out.println("\tUnfortunatelly no matches");
        for(String el : matches){
            System.out.println("\t*" + el);
        } 
        System.out.println("-----------------------\n");
    }
}