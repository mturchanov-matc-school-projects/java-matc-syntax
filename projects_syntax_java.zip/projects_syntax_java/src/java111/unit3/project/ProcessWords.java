public class ProcessWords{

    public void processWords(){
        MakeListWords processWords = new MakeListWords();

        while(processWords.getWordsAreFun()){
            processWords.addWords();
        }
        processWords.getResults();
    }
}