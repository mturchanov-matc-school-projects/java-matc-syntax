import java.io.*;


/** 
*
* the class prompt user to enter
* to console
* @author knapp
*
*/


public class    InputHelper {

    /**
     * 
     * the method promts user to enter some data
     * to a console
     * @param prompt 
     * @return String inputLine 
     */
    public String getUserInput(String prompt) {
        String  inputLine  = null;
        System.out.print(prompt + "  ");
        try {
            BufferedReader  input = 
                    new BufferedReader(
                    new InputStreamReader(System.in));
            inputLine = input.readLine();
        
        } catch (IOException|NullPointerException exception) {           
            System.out.println("IOException: " + exception);
        }
        
        return inputLine;
    }
}

