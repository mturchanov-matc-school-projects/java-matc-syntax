/** 
*
* TThis class contains 
* all Mowing company prices
*
* @author mturchanov
*
*/

public class MowingCompany{
    public static int seasonLength = 20;
    public static int chargeSmallWeekly = 25;
    public static int chargeMediumWeekly = 35;
    public static int chargeLargeWeekly = 50;

    public static int twoPaymentsCharge = 5;
    public static int manyPaymentsCharge = 3;

    public static int chargeSmallFull = chargeSmallWeekly * seasonLength;
    public static int chargeMediumFull = chargeMediumWeekly * seasonLength;
    public static int chargeLargeFull = chargeLargeWeekly * seasonLength;

}