/** 
*
* This class represents a Client
*
*@author mturchanov
*/
public class Client{
    private String name;   
    private double lawnSize;
    private int paymentsNum;
    private double clientFullCharge;
    private double amountOfEachPayment;

  
    /**
    * This constructor set all main client's information
    *
    * @param name The name of the client
    * @param lawnLength The length of  a lan
    * @param lawnWidth The width of a lawn
    * @param paymentsNum Number of each payment
    *
    */
    public void setClientInfo(String name, double lawnLength, double lawnWidth,int paymentsNum ){
        this.name = name;
        this.lawnSize = lawnLength * lawnWidth;
        this.paymentsNum = paymentsNum;
    }

    /** 
    *
    * This methods calculate and sets amount of each payment
    *
    * @return The daily sales of the theater.
    *
    */
    public void calculateClientCharges(){
        if (lawnSize < 400) {
            clientFullCharge = MowingCompany.chargeSmallFull; 
        } else if(lawnSize >= 400 && lawnSize < 600) {
            clientFullCharge = MowingCompany.chargeMediumFull;
        } else {
            clientFullCharge = MowingCompany.chargeLargeFull;
        }
        if(paymentsNum == 2) {
            clientFullCharge += MowingCompany.twoPaymentsCharge * paymentsNum;
        } else if(paymentsNum > 2) {
            clientFullCharge += MowingCompany.manyPaymentsCharge * paymentsNum;
        } 
        amountOfEachPayment = clientFullCharge / paymentsNum;
    }

     /** 
    *
    * This methods retrieves a client's lawn size
    *
    * @return a lawn size
    *
    */
    public double getLawnSize(){
        return lawnSize;
    }

    /** 
    *
    * This methods retrieves a client's full charge
    *
    * @return a client's full charge
    *
    */
    public double getClientFullCharge(){
        return clientFullCharge;
    }


    /** 
    *
    * This methods display all client's information to a console
    *
    * 
    *
    */
    public void getFullClientInfo(){
        String fullClientInfo = String.format("%n> Client: %s" + "%n> Lawn Size: %.2f sq. ft.%n"
                + "> Number of Payments: %s"
                + "%n> Amount of each payment: %.2f"
                + "%n> Total of all payments: %.2f", 
                name, lawnSize, paymentsNum, amountOfEachPayment, clientFullCharge);
        System.out.println(fullClientInfo);    
    }
}