
/** 
*
* The entry point of the application/output.
*
* @author mturchanov
*
*/
public class ClientsReportTestDrive {
    public static void main(String[] args) throws Exception{
       ClientsReport output = new ClientsReport();
       output.output();
    }   
}