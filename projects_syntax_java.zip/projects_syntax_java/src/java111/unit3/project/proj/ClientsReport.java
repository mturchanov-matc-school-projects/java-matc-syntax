import java.util.*;

/** 
*
* This class create/produce a client's report
*
*@author mturchanov
*/
public class ClientsReport{
    private List <Client> clients;
    private double totalLawnSize;
    private double totalRevenue;
    private int clientsNumber;


    /** 
    *
    * This methods add a client to a report client list(pseudo-DB)
    *
    * 
    *
    */
    public void addClients(){
        InputHelper input = new InputHelper();
        clients = new ArrayList<>();     
        clientsNumber = 0;
        while(true){
            String anotherOne = "";

            if(clientsNumber > 0){
                anotherOne = input.getUserInput("\nDo you want to add a new client?(y/n)");
                if(anotherOne.equals("n")) return;
                else if(anotherOne.equals("y")) processClientsInfo();
                else System.out.println("\nEnter either yes or no.\n('n'/'y')\n"); 
            } else processClientsInfo();           
        }
    }

    /** 
    *
    * This methods process, gather(via input) information 
    * to produce a client report
    * 
    *
    */
    public void processClientsInfo(){
        InputHelper input = new InputHelper();
        clients.add(new Client());
        String name = input.getUserInput("\nEnter a name of the client.");
        double lawnLength = Double.parseDouble(input.getUserInput("\nEnter the client's lawn length."));
        double lawnWidth = Double.parseDouble(input.getUserInput("\nEnter the client's lawn width."));
        int paymentsNum = Integer.parseInt(input.getUserInput("\nEnter number of payments that the client does/will do."));
        clients.get(clientsNumber).setClientInfo(name, lawnLength, lawnWidth, paymentsNum);
        clients.get(clientsNumber).calculateClientCharges();
        clientsNumber++;
    }


    /** 
    *
    * This methods calculate and 
    * set total lawn size of all client clients (that are in report)
    * 
    */
    public void calculateTotalLawnSize(){
        for(Client client : clients){
            totalLawnSize += client.getLawnSize();
        }
    }

    /** 
    *
    * This methods calculate and 
    * set total revenue 
    * 
    */
    public void calculateTotalRevenue(){
        for(Client client : clients){
            totalRevenue += client.getClientFullCharge();
        }
    }

    /** 
    *
    * This methods display  
    * information of each client(that is in a report)
    * 
    */
    public void getClientsReport(){
        for(Client client : clients){
            client.getFullClientInfo();
        }
    }

    /** 
    *
    * This methods generate  
    * a summary report
    * 
    */
    public void getSummaryReport(){
        String summaryReport = String.format("\nSummaryReport:\n\n> Total Number of clients: %s"
                + "\n> Total Square Feet of Mowing: %.2f" + "\n> Total Revenue for the summer: %.2f",
                clientsNumber, totalLawnSize, totalRevenue);
        System.out.println(summaryReport);

    }

    /** 
    *
    * This method embrace all
    * report tasks and generate 
    * an output 
    *
    */
    public void output(){
        addClients();
        calculateTotalLawnSize();
        calculateTotalRevenue();
        System.out.println("\nClients report:");
        getClientsReport();
        getSummaryReport();
    }
    
}