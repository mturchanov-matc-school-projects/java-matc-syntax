class Employee{
    private String firstName;
    private String lastName;
    private int id;

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public void setId(int id){
        this.id = id;
    }

    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public int getId(){
        return id;
    }

    public void getEmployeeData(){
        String empInfo = "\nEmloyee's first name: " + firstName + "\nEmployee's last name: " + lastName
                + "\nEmployee's ID: " + id + "\n------------------------\n";
        System.out.println(empInfo);
    }

}