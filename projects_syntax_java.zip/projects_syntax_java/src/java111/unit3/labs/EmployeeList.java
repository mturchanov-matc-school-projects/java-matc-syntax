import java.util.ArrayList;
import java.util.Arrays;

public class EmployeeList{
    private ArrayList<Employee> employeeList;

    public void run(){
        employeeList = new ArrayList<>(Arrays.asList(new Employee(), new Employee(), new Employee(), new Employee()));
        settingEmployee(employeeList.get(0), "Mike", "Turchanov", 1);
        settingEmployee(employeeList.get(1), "Dima", "Markov", 2);
        settingEmployee(employeeList.get(2), "Anna", "Vasilieva", 3);
        settingEmployee(employeeList.get(3), "Elisa", "Johnson", 4);  
        
        for(Employee worker : employeeList){
            worker.getEmployeeData();
        }
    }

    public void settingEmployee(Employee employee, String fname, String lname, int id){
        employee.setFirstName(fname);
        employee.setLastName(lname);
        employee.setId(id);
    }

}