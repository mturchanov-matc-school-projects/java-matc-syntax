public class EmployeeListTestDrive{
    public static void main(String[] args){
        EmployeeList output = new EmployeeList();
        output.run();
    }
}