/**
 *  Application 1
 *    **Goal**: Calculate the sum, difference, multiplication product, and division product of two numbers entered by a user. Keep asking for more input and showing output until the user enters a 0.
 *    **Setup**: When the application is launched it will ask the user for numbers and then output the calculations.
 *    **Suggested classes**: CalculatorTestDrive, Calculator, Output
 * 
 * 
 */


public class Calculator{

    private int num1;
    private int num2;

    public void setNumbers(int num1, int num2){
        this.num1 = num1;
        this.num2 = num2;
    }

    public int getSum(){
        return this.num1 + this.num2;
    }

    public int getDifference(){
        return this.num1 - this.num2;
    }

    public int getMultiplicaton(){
        return this.num1 * this.num2;
    }

    public double getDivision(){
        return this.num1 / (double)this.num2;
    }

    
}