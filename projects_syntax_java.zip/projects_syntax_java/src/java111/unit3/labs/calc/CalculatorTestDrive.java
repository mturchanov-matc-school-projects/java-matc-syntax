import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CalculatorTestDrive{
    public static void main(String[] args){
        InputHelper input = new InputHelper();
        Output output = new Output();
        output.getAllResults();
            }
}