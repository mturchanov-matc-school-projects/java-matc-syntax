public class Output{
    public void getAllResults(){
        Calculator calc = new Calculator();
        InputHelper input = new InputHelper();

        while(true){
            int num1 = Integer.parseInt(input.getUserInput("Enter the first number for the application"));
            if(num1 == 0) {
                System.out.println("Calculation is finished");
                 break;
            }
            int num2 = Integer.parseInt(input.getUserInput("Enter the second number for the application"));
            if(num2 == 0) {
                System.out.println("Calculation is finished");
                 break;
            }
            calc.setNumbers(num1,num2);
            
            System.out.println("Your result: \nSum: " + calc.getSum() + "\nDifference: " + calc.getDifference()
                    + "\nMultiplication: " + calc.getMultiplicaton() + "\nDivision: " + calc.getDivision());
            System.out.println("---------------------\n");
        }


        
    }
}