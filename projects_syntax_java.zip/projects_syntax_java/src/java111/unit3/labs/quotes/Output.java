public class Output{
    
    public void launchTheQuoteMachine(){
        InputHelper input = new InputHelper();
        Quotes quotes = new Quotes();

        while(!quotes.getColorAvailable()){
            String color = input.getUserInput("Enter a color and get a quote!");
            quotes.getColorQuote(color);
        }
    }
}