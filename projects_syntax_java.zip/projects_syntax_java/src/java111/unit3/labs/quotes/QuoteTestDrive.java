public class QuoteTestDrive{
    public static void main(String[] args){
        Output output = new Output();
        output.launchTheQuoteMachine();
    }
}