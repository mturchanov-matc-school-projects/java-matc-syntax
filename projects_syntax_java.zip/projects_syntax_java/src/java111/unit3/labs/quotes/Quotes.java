import java.util.ArrayList;
import java.util.Arrays;


public class Quotes{
    private ArrayList<String> colorQuotes = new ArrayList<>(Arrays.asList("\n\"In the winter, the Love comes wearing a white dress\"",
            "\n\"In the spring the Love has a blue dress\"", "\n\"In the summer the Love wears a green dress\"", 
            "\n\"The Love has a golden dress in the automn\""));
    private ArrayList<String> colors = new ArrayList<>(Arrays.asList("white", "blue", "green", "golden"));
    private boolean colorAvailable = false;


    public boolean getColorAvailable(){
        return colorAvailable;
    }
    public void getColorQuote(String color){

        if(colors.contains(color)){
            for( String quote : colorQuotes){
                if(quote.contains(color)){
                    System.out.println(quote);
                    System.out.println("\nApplicaltion has finished" + "...");
                    colorAvailable = true;
                    return;
                }
            }
        } else {
            System.out.println("No such color!");
        }  

    }
}



