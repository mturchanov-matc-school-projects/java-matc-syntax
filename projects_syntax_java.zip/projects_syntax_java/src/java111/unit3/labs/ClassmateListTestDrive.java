public class ClassmateListTestDrive{
    public static void main(String[] args){
    ClassmateList output = new ClassmateList();
    output.run();
    }
}