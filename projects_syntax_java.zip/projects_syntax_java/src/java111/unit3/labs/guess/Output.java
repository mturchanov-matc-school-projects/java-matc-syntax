import java.io.IOException;

public class Output{
    public void launchGuessingApp() throws IOException, InterruptedException
    {
        GameEngine game = new GameEngine();
        GuessingGuy guy = new GuessingGuy();
        InputHelper input = new InputHelper();

        game.setSearchField(game.setMaxRange());
        game.generateNumber();
        guy.setRanges(game.getSearchField());

        while(!game.getNumberIsGuessed())
        {
            guy.guessingGuyInput();
            int guessNum = Integer.parseInt(input.getUserInput("Guess a number between 1 and "
                    + game.getMaxRangeNum()));

            game.setGuessNum(guessNum);
            GuessResult result = game.processGame();
            guy.guessingGuyChoice(result);
        }

    }
}