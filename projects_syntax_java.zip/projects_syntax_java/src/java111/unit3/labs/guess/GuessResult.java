public enum GuessResult
{
    LOW,
    RIGHT,
    HIGH,
    OUT_OF_RANGE
}