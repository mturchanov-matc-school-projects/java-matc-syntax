import java.io.*;

public class    InputHelper
{

    public String getUserInput(String prompt) throws IOException
    {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader reader = new BufferedReader(isr);
        String line = "";
        while (true)
        {
            line = reader.readLine();
            if (line == null) break;
            System.out.println("Maybe " + line + "?\n");
            reader.close();
            isr.close();
            return line;
        }
        return null;
    }
}
