import java.io.*;

public class GameTestDrive{
    public static void main(String[] args) throws IOException, InterruptedException 
    {
        Output output = new Output();
        output.launchGuessingApp();
    }
}