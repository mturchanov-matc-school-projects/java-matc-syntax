import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class GameEngine
{
    private int rightNumber;
    private int guessNum;
    private boolean numberIsGuessed = false;
    private int[] searchField;
    private int maxRangeNum;
    private int howManyTimes;


    public void generateNumber()
    {
        Random rand = new Random();
        rightNumber = rand.nextInt(maxRangeNum + 1);
    }

    public boolean getNumberIsGuessed()
    {
        return numberIsGuessed;
    }

    public void setGuessNum(int num)
    {
        guessNum = num;
    }

    public int getMaxRangeNum()
    {
        return maxRangeNum;
    }

    public GuessResult processGame()
    {
        howManyTimes++;

        if(guessNum > rightNumber)
        {
            System.out.println("Nope. You have entered too big number. Try one more time");
            return GuessResult.HIGH;
        }
        else if(guessNum < rightNumber )
        {
            System.out.println("Nope. You have entered too small number. Try one more time");
            return GuessResult.LOW;
        }
        else if(guessNum == rightNumber)
        {
            System.out.println("You spent " + howManyTimes + " attempts. You guessed right. Goodbye!");
            System.out.println("----------------------------\n");
            numberIsGuessed = true;
            return GuessResult.RIGHT;
        }
        else
        {
            System.out.println("Out of range. The number should be between 1 and 100");
        }
        return GuessResult.OUT_OF_RANGE;
    }

    public void setSearchField(int size)
    {
        searchField = new int[size];
        for(int i = 0; i < searchField.length; i++) searchField[i] = i;
    }

    public int setMaxRange() throws IOException
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("A minimal guessed value is 0 and the max is...\n" +
                "(please enter a max range number");
        maxRangeNum = Integer.parseInt(reader.readLine());
        return maxRangeNum;
    }

    public int[] getSearchField()
    {
        return searchField;
    }
}