
import java.io.*;

public class GuessingGuy
{
    private int guessingGuyGuess;
    private int low;
    private int high;
    private int mid;


    public void guessingGuyChoice(GuessResult result) throws InterruptedException
    {
        int counter = 0;

        if(result == GuessResult.RIGHT)
        {
            System.out.print("Hooray, that's the number ");
            return;
        }
        else if(result == GuessResult.HIGH)
        {
            high = mid - 1;
            System.out.println("Damn...too big");
        }
        else if(result == GuessResult.LOW)
        {
            low = mid + 1;
            System.out.println("Damn...too low");
        }

        System.out.println("\t-Okay. Let me think");
        while(counter < 10)
        {
            System.out.print(".");
            Thread.sleep(1000);
            counter++;
        }
        mid = (int) Math.round((Double.valueOf(low)+high)/2);

        guessingGuyGuess = mid;
    }

    public void setRanges(int[] searchField)
    {
        low = searchField[0];
        high = searchField[searchField.length-1];
        mid = (int) Math.round((Double.valueOf(low)+high)/2);
        guessingGuyGuess = mid;

    }

    public void guessingGuyInput() throws IOException
    {
        InputStream is = new ByteArrayInputStream(String.valueOf(guessingGuyGuess).getBytes());
        System.setIn(is);
        is.close();
    }
}