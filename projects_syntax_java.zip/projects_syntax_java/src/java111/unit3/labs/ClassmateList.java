import java.util.ArrayList;
import java.util.Arrays;

public class ClassmateList{
    private ArrayList<String> list;

    public void run(){
        ArrayList<String> list = new ArrayList<>(Arrays.asList("Hello my name is Mike and I provide some strings".split(" ")));
        for(String str: list){
            System.out.println(str);
        }
        System.out.println("------------Delete something----------------");
        list.remove(Math.round(list.size() / 2));
        for(String str: list){
            System.out.println(str);
        }
        System.out.println("----------------------------\n");

    }
}