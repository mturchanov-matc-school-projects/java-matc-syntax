public class LabUserInput{
    private boolean loopIsFun = true;
    InputHelper input = new InputHelper();

    void run (){
        while(loopIsFun){
            try{
                String str = input.getUserInput("Enter something! Or quit");
            if(str.toLowerCase().equals("quit")) loopIsFun = false;
            } catch(Exception e){
                System.out.println("Yoy should enter something. Try again or quit");
                run();
            }
        }
    }
}