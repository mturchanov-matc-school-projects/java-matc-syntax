public class Lab6TestDrive{
    public static void main(String[] args){
        LabUserInput output = new LabUserInput();

        output.run();
    }
}