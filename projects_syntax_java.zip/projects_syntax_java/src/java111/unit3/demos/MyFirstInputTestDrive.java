public class MyFirstInputTestDrive{
    public static void main(String[] args){
        InputHelper input = new InputHelper();
        String inputResult = input.getUserInput("Question?"); 
        if (inputResult.equals("25")){
            System.out.println("You are old");
        } else if(Integer.parseInt(inputResult) > 14){
            System.out.println("Price 14.55 dollars");
         }else{
             System.out.println("You typed this: " + inputResult);

        }
    }
}