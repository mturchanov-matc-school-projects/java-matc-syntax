import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class FunWithArrayLists{
    public static void main(String[] args){
        ArrayList<Integer> toDos = new java.util.ArrayList<>(Arrays.asList(1,2,3,4,5,6));
        int num1 = 5;
        toDos.add(5);
        // toDos.add("buy Milk");
        // toDos.add("Spinach");
        // toDos.add("Peanut Butter");
        // toDos.add("Tune up smt");

        for(Integer el: toDos){
            System.out.println(el);
        }
    }
}